
/**
 * Write a description of class Background here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Background {

    private Obrazok obrazokPozadie;
    private Obrazok obrazokPozadiePozadia;
    private Obrazok[] obrazokPower;
    private int pocetPower = 0;
    private int pocitadlo = 0;
    private NekonecnocifernyDisplej zivoty;
    private NekonecnocifernyDisplej skore;
    private NekonecnocifernyDisplej cas;
    
    private static final int SIRKA_PLATNA = 800;
    private static final int VYSKA_PLATNA = 600;
    private static final int VYSKAPRVKOV = 72;
    private static final int VELKOSTDISPLEJA = 20;

    public Background(int pocetHP, int pocetMaxPower, int cas) {
        
        this.zivoty = new NekonecnocifernyDisplej(75, this.VYSKA_PLATNA - ((VYSKAPRVKOV / 4) * 3), VELKOSTDISPLEJA, 3); 
        this.zivoty.setDisplej(pocetHP);
        this.zivoty.zobrazAktualnuHodnotu();
        this.skore = new NekonecnocifernyDisplej(this.SIRKA_PLATNA / 2 + this.SIRKA_PLATNA / 4, 0 + VYSKAPRVKOV / 4, VELKOSTDISPLEJA, 5);
        this.skore.setDisplej(0);
        this.skore.zobrazAktualnuHodnotu();
        this.cas = new NekonecnocifernyDisplej(100, VYSKAPRVKOV / 4, VELKOSTDISPLEJA, 2);
        this.cas.setDisplej(cas);
        this.cas.zobrazAktualnuHodnotu();
        this.obrazokPozadie = new Obrazok("pics/pozadie.png");
        this.obrazokPozadie.zmenPolohu(400, 300); //vytvoreny 800x600 obrazok, polovicka z kazdej suradnice
        this.obrazokPozadie.zobraz();
        this.obrazokPower = new Obrazok[pocetMaxPower];

        for (int indexPower = 0; indexPower < this.obrazokPower.length; indexPower++) {

            this.obrazokPower[indexPower] = new Obrazok("pics/powerOff.png"); //8*15
            this.obrazokPower[indexPower].zmenPolohu(220 + (25 * indexPower), 565);
            this.obrazokPower[indexPower].zobraz();
        }
        //obrazokPower = new Obrazok("pics/power.png"); //8*15
        //obrazokPower.zmenPolohu(220, 565);
        //obrazokPower.zobraz();

    }

    /**
     * Method pridajPower
     * zozltne jedna power
     */
    public void pridajPower() {
        if (this.pocetPower == this.obrazokPower.length) {
            return;
        }
        this.obrazokPower[this.pocetPower].zmenObrazok("pics/powerOn.png");
        this.pocetPower += 1 ;

    }

    /**
     * Method odoberPower
     * zosivne jedna power
     */
    public void odoberPower () {
        if (this.pocetPower == 0) {
            return;
        }
        this.pocetPower -= 1 ;
        this.obrazokPower[this.pocetPower].zmenObrazok("pics/powerOff.png");

    }

    /**
     * Method odcitajSekundu
     * odcita sekundu, posle ci sa to da alebo nie
     * @return The return value
     */
    public boolean odcitajSekundu() {
        this.pocitadlo += 1;
        if ((this.pocitadlo % 2) != 0) {
            return true;
        }
        int casHodnota = this.cas.getAktualnaHodnota() - 1;
        this.cas.setDisplej(casHodnota);
        if (casHodnota == 0) {
            return false;
        }
        return true;

    }

    /**
     * Method getCas
     * vrati aktualny cas
     * @return The return value
     */
    public int getCas() {
        return this.cas.getAktualnaHodnota();
    }

    /**
     * Method setSkore
     *nastavi skore na displeji
     * @param skore A parameter
     */
    public void setSkore(int skore) {
        this.skore.setDisplej(skore);

        //this.skore.zobrazAktualnuHodnotu();

    }

    /**
     * Method vymazDispleje
     * vymaze vsetky prvky backgroundu
     */
    public void vymazDispleje() {
        this.cas.zhasniVsetky();
        this.zivoty.zhasniVsetky();
        this.skore.zhasniVsetky();
        this.obrazokPozadie.skry();
        for (int indexPower = 0; indexPower < this.obrazokPower.length; indexPower++) {
            this.obrazokPower[indexPower].skry();
            //this.obrazokPower[indexPower] = null; //8*15

        }
    }

    /**
     * Method odcitajHP
     * odcita hp, ak sa neda, tak posle ze sa neda - false
     * @param kolko A parameter
     * @return The return value
     */
    public boolean odcitajHP(int kolko) {
        if (this.pocetPower != 0) {
            this.odoberPower();
            return true;
        }
        
        int zivotyHodnota = this.zivoty.getAktualnaHodnota();
        this.zivoty.setDisplej((zivotyHodnota) - kolko);
        if (this.zivoty.getAktualnaHodnota() == 0) {
            return false;
        }

        return true;

    }

    /**
     * Method getPower
     * ziskam kolko je power
     * @return The return value
     */
    public int getPower() {
        return this.pocetPower;
    }

}
