import javax.swing.Timer;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
/**
 * Write a description of class DvojcifernyDisplej here.
 *  dvojciferny displej zmeneny na dynamicky displej - cize kolko ciferny chcem, tak sa tolko ciferny spravi
 * @author Cvicenia+ Karol S.
 * @version 1.1.2022
 */
public class NekonecnocifernyDisplej {
   
    private SSD[] displej;
    private int aktualnaHodnota;
    private int y;
    private int x;
    private int velkost;
    private int pocetMiest;
    private String[] slovo;
    private boolean zasvieteny;
    private boolean mamCislo;

    /**
     * Constructor for objects of class DvojcifernyDisplej
     * vytvorim podla zadaneho poctu "pocetMiest" displeje
     * ulozim si x , y velkost , slovo podla pocetMiest nastavim. 
     * pri nastavovani pismena alebo cisla vyuzivam mamCislo , takze viem, na co sa ma displej pozerat
     * 
     */ //SSD(int x, int y, Farba farba, int sirkaCelehoSSD, int vyskaCelehoSSD)
    public NekonecnocifernyDisplej(int poziciaDisplejaX, int poziciaDisplejaY, int velkost, int pocetMiest ) {
        int polvelkosti = velkost / 2;
        this.pocetMiest = pocetMiest;
        this.displej = new SSD[pocetMiest];
        this.displej[0] = new SSD(poziciaDisplejaX, poziciaDisplejaY, Farba.CIERNA, velkost, velkost * 2);
        for (int i = 1; i < pocetMiest; i++ ) {
            this.displej[i] = new SSD(this.displej[i - 1].getX() + polvelkosti * 3, poziciaDisplejaY, Farba.CIERNA, velkost, velkost * 2);

        
        }
        
        //this.displej[0] = new SSD(poziciaDisplejaX, poziciaDisplejaY, Farba.CIERNA, velkost, velkost * 2);
        //this.displej[1] = new SSD(this.displej[0].getX() + polvelkosti * 3, poziciaDisplejaY, Farba.CIERNA, velkost, velkost * 2);
        //this.displej[2] = new SSD(this.displej[1].getX() + polvelkosti * 3, poziciaDisplejaY, Farba.CIERNA, velkost, velkost * 2);
        //this.displej[3] = new SSD(this.displej[2].getX() + polvelkosti * 3, poziciaDisplejaY, Farba.CIERNA, velkost, velkost * 2);
        //this.displej[4] = new SSD(this.displej[3].getX() + polvelkosti * 3, poziciaDisplejaY, Farba.CIERNA, velkost, velkost * 2);
        this.y = poziciaDisplejaY;
        this.velkost = velkost;
        this.x = poziciaDisplejaX;
        this.aktualnaHodnota = 0;
        this.slovo = new String [pocetMiest];
        this.zasvieteny = false;
        this.mamCislo = true;
    }

    /**
     * Method setFarbuVsetkych
     * nastavi farbu vsetkych cifier
     * @param farba A parameter
     */
    public void setFarbuVsetkych(Farba farba) {
        for (int i = 0; i < this.displej.length; i++) {
            this.displej[i].setFarba(farba);

        }
    }

    
    
    /**
     * Method getAktualnaHodnota
     * skopirovane z hodiny
     * @return The return value
     */
    public int getAktualnaHodnota() {   
        return this.aktualnaHodnota;   
    }

    

    /**
     * Method vynulujSlovo
     * vymaze slovo
     */
    public void vynulujSlovo() {

        for (int i = 0; i < this.pocetMiest; i++) {
            this.slovo[i] = " ";

        }

    }

    /**
     * Method setDisplej
     * overload String nastavi string pismeno 
     * @param pismeno A parameter
     */
    public void setDisplej(String pismeno) {
        this.vynulujSlovo();
        pismeno = pismeno.toUpperCase();
        char[] slovoArray = new char[pismeno.length()];
        for (int i = 0; i < pismeno.length(); i++) {
            if (i >= pocetMiest) {
                continue;
            }
            this.slovo[i] = pismeno.substring(i, i + 1);
        } 

        this.mamCislo = false;

        if (this.zasvieteny) {
            this.zobrazAktualnuHodnotu();

        }
    }
    
    /**
     * Method setDisplej
     * overload Integer nastavi Integer cislo
     * @param pismeno A parameter
     */
    public void setDisplej(int cislo) {
        
        int dlzka = 1;
        if (cislo != 0) {
            dlzka = (int)(Math.log10 (cislo) + 1);
            if (dlzka > this.displej.length) {
                cislo = 9;
            }
        }
        
        
        // if (cislo > 99999) {
            // cislo = 99999;
        // }
        this.aktualnaHodnota = cislo;
        this.mamCislo = true; 

        if (this.zasvieteny) {
            this.zobrazAktualnuHodnotu();

        }

    }
    
    /**
     * Metho d zobrazAktualnuHodnotu
     * zobrazi aktualnu hodnotu, cize ci integer alebo string a zobrazi nalavo zarovnane, zarovnanie cez modulo a delitel pocitane
     * dlzka pocitana cez logaritmus
     */
    public void zobrazAktualnuHodnotu() {
        this.zasvieteny = true;
        if (this.mamCislo) { //aktualna hodnota = 16 111

            int dlzka = 1;
            if (this.aktualnaHodnota != 0) {
                dlzka = (int)(Math.log10 (this.aktualnaHodnota) + 1);

            }

            int modulo = (int)Math.pow(10, dlzka);   //161
            int delitel = (int)Math.pow(10, dlzka - 1);

            for (int i = 0; i < dlzka; i++) {
                this.displej[i].nastav((this.aktualnaHodnota % modulo ) / delitel);
                modulo = modulo / 10;
                delitel = modulo / 10;

            }

            for (int i = dlzka; i < this.pocetMiest; i++) {
                this.displej[i].nastav(10);
            }

        } else {

            for (int i = 0; i < this.slovo.length; i++) {
                this.displej[i].nastav(this.slovo[i]);
            }

            for (int i = this.slovo.length; i < this.pocetMiest; i++) {
                this.displej[i].nastav(10);

            } 
        }

    }

    /**
     * Method zasvietZhasniTimeout
     * skopirovane z netu
     * bliknutie displeja
     * @param cas A parameter
     */
    public void zasvietZhasniTimeout(int cas) { 
        this.zobrazAktualnuHodnotu();
        Timer timer = new Timer(cas * 500, new ActionListener() {
                @Override
                    public void actionPerformed(ActionEvent arg0) {
                NekonecnocifernyDisplej.this.zhasniVsetky();
                }
            });
        timer.setRepeats(false); 
        timer.start(); //zacne,pocka pol sekundy,  zavola actionPerformed

    }

    /**
     * Method pridaj
     * pridam cislo a zobrazi sa 
     * @param o kolko 
     */
    public void pridaj(int kolko) {
        if (this.aktualnaHodnota == 99999) {
            return;
        }
        this.aktualnaHodnota = this.aktualnaHodnota + kolko;
        if (this.getZasvieteny()) {
            this.zobrazAktualnuHodnotu();
        }

    }

    /**
     * Method getZasvietenyStatus
     * pytam sa ci je zasvieteny
     * @return The return value
     */
    public boolean getZasvieteny() {
        return this.zasvieteny;

    }

    /**
     * Method zhasniVsetky
     * zhasne vsetky cifry
     */
    public void zhasniVsetky() {

        for (int i = 0; i < this.displej.length; i++) {
            if (this.displej[i] == null) {
                continue;
            }
            this.displej[i].zhasniVsetko();
        }
        this.zasvieteny = false;
    }

}

