import java.awt.geom.Ellipse2D;
import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;
/**
 * Kruh, s ktorým možno pohybovať a nakreslí sa na plátno.
 * Upraveny na zobrazovanie 
 * @author  Michael Kolling and David J. Barnes
 * @version 1.0  (15 July 2000)
 */

public class Kruh {
    private int priemer;
    private int x;
    private int y;
    private String farba;
    private boolean jeViditelny;
    private boolean somVybuchnuty;
    private int pocitadlo;
    private int skore;
    private static Kruh instance = null;
    /**
     * Vytvor nový kruh preddefinovanej farby na preddefinovanej pozícii. 
     */
    public Kruh() {
        this.priemer = 50;
        this.x = 20;
        this.y = 60;
        this.farba = "blue";
        this.jeViditelny = false;
        this.somVybuchnuty = false;
        this.pocitadlo = 0;
    }

    /**
     * chcem len 1 instanciu kruhu, bolo by nemozne kliknut na viacero kruhov naraz
     *
     * @return 1 instanciu 
     */
    public static Kruh getInstance() {  //zabranenie, aby sa vytvorilo viacero instancii
        if (Kruh.instance == null) {    //lebo chcem len 1 hru
            Kruh.instance = new Kruh();
        }

        return Kruh.instance;
    }

    public void vyberSuradnice(int x, int y) {
        if ((!this.getVybuchni()) && (this.somTam(x, y))) {
            this.skry();
        }        
    }

    public boolean jeViditelny() {
        return this.jeViditelny;
    }

    /**
     * Method getScoreKruhu
     *
     * @return vrati, kolko skore v sebe drzi.
     */
    public int getScoreKruhu() {
        return this.skore;
    }

    /**
     * Method somTam
     * tvar samotny urci, ci je v tychto suradniciach a odpoveda len ano alebo nie
     * ak je, tak si automaticky sam nastavi si 300 bodov a posle ich do mapy.. no teda mapa si ich nasledne vypyta
     * @param x suradnica X
     * @param y suradnica Y
     * @return vrati, ci tento tvar je v zadanych suradniciach
     */
    public boolean somTam(int x, int y) {

        if ((Math.pow(x - this.x, 2) + Math.pow(y - this.y, 2) < Math.pow(this.priemer, 2)) && (this.jeViditelny())) {
            this.skore = 300;
            URL url = Stvorec.class.getResource("sounds/klik.wav");
            AudioClip clip = Applet.newAudioClip(url);
            clip.play();
            url = null;
            clip = null;

            return true;
        }
        return false;
    }
    /**
     * Method setVybuchni
     * nastavenie, ci je vybuchnuty tvar
     * @param nastavenie true false 
     */

    /**
     * Method zresetujPocitadlo
     * reset pocitadla na 0
     */
    public void zresetujPocitadlo() {
        this.pocitadlo = 0;
    }

    /**
     * Method getVybuchni
     *
     * @return premenovane na getVybuchni, vracia, ci je tvar vybuchnuty alebo nie
     */
    public boolean getVybuchni() {
        return this.somVybuchnuty;
    }

    /**
     * Method setVybuchni
     * nastavi , ci je vybucnhuty
     * @param bum A parameter
     */
    public void setVybuchni (boolean bum) {
        this.somVybuchnuty = bum;
    }

    /**
     * Method vybuchni
     * tvar vybuchne, pusti bum.wav subor a zaroven vymaze odkazy a referencie na objekty url a clip
     */
    public void vybuchni() {
        this.somVybuchnuty = true;

        URL url = Stvorec.class.getResource("sounds/bum.wav");
        AudioClip clip = Applet.newAudioClip(url);
        clip.play();
        url = null;
        clip = null;
        this.skry();

    }

    /**
     * Method tik
     * metoda prida do pocitadla +1 a ak bude 5 alebo viac a je viditelny, tak vybuchne. kvazi taka "tikajuca bomba"
     */
    public void tik() {
        this.pocitadlo += 1;
        this.nakresli();
        if ((this.pocitadlo > 4) && (this.jeViditelny())) {
            this.vybuchni();
            this.jeViditelny = false;
            this.pocitadlo = 0;
        }
    }

    /**
     * (Kruh) Zobraz sa.
     */
    public void zobraz() {
        this.jeViditelny = true;
        this.nakresli();
    }

    /**
     * (Kruh) Skry sa.
     */
    public void skry() {
        this.zmaz();
        this.jeViditelny = false;
    }

    /**
     * (Kruh) Posuň sa vpravo o pevnú dĺžku. 
     */
    public void posunVpravo() {
        this.posunVodorovne(20);
    }

    /**
     * (Kruh) Posuň sa vľavo o pevnú dĺžku. 
     */
    public void posunVlavo() {
        this.posunVodorovne(-20);
    }

    /**
     * (Kruh) Posuň sa hore o pevnú dĺžku. 
     */
    public void posunHore() {
        this.posunZvisle(-20);
    }

    /**
     * (Kruh) Posuň sa dole o pevnú dĺžku. 
     */
    public void posunDole() {
        this.posunZvisle(20);
    }

    /**
     * (Kruh) Posuň sa vodorovne o dĺžku danú parametrom. 
     */
    public void posunVodorovne(int vzdialenost) {
        this.zmaz();
        this.x += vzdialenost;
        this.nakresli();
    }

    /**
     * (Kruh) Posuň sa zvisle o dĺžku danú parametrom. 
     */
    public void posunZvisle(int vzdialenost) {
        this.zmaz();
        this.y += vzdialenost;
        this.nakresli();
    }

    /**
     * (Kruh) Posuň sa pomaly vodorovne o dĺžku danú parametrom. 
     */
    public void pomalyPosunVodorovne(int vzdialenost) {
        int delta;

        if (vzdialenost < 0) {
            delta = -1;
            vzdialenost = -vzdialenost;
        } else {
            delta = 1;
        }

        for (int i = 0; i < vzdialenost; i++) {
            this.x += delta;
            this.nakresli();
        }
    }

    /**
     * (Kruh) Posuň sa pomaly zvisle o dĺžku danú parametrom. 
     */
    public void pomalyPosunZvisle(int vzdialenost) {
        int delta;

        if (vzdialenost < 0) {
            delta = -1;
            vzdialenost = -vzdialenost;
        } else {
            delta = 1;
        }

        for (int i = 0; i < vzdialenost; i++) {
            this.y += delta;
            this.nakresli();
        }
    }

    /**
     * (Kruh) Zmeň priemer na hodnotu danú parametrom.
     * Priemer musí byť nezáporné celé číslo. 
     */
    public void zmenPriemer(int priemer) {
        this.zmaz();
        this.priemer = priemer;
        this.nakresli();
    }    

    public void zmenPolohu(int lavyHornyX, int lavyHornyY) {
        boolean nakresleny = this.jeViditelny;
        this.zmaz();
        this.x = lavyHornyX;
        this.y = lavyHornyY;
        if (nakresleny) {
            this.nakresli();
        }
    }

    /**
     * (Kruh) Zmeň farbu na hodnotu danú parametrom.
     * Nazov farby musí byť po anglicky.
     * Možné farby sú tieto:
     * červená - "red"
     * žltá    - "yellow"
     * modrá   - "blue"
     * zelená  - "green"
     * fialová - "magenta"
     * čierna  - "black"
     */
    public void zmenFarbu(String farba) {
        this.farba = farba;
        this.nakresli();
    }

    /**
     * Method nakresli
     * upravena tak, aby vzdy kruh menil farbu pri vykresleni, 
     * tu mi uhol netreba, tak som nechal canvas.draw
     */
    /*
     * Draw the circle with current specifications on screen.
     */
    private void nakresli() {
        if (this.jeViditelny) {
            String farbaRandomString = Farba.randomFarbaString();
            this.farba = farbaRandomString;
            Platno canvas = Platno.dajPlatno();
            canvas.draw(this, this.farba, new Ellipse2D.Double(this.x, this.y, 
                    this.priemer, this.priemer));
            canvas.wait(2);
        }
    }

    /*
     * Erase the circle on screen.
     */
    private void zmaz() {
        if (this.jeViditelny) {
            Platno canvas = Platno.dajPlatno();
            canvas.erase(this);
        }
    }
}
