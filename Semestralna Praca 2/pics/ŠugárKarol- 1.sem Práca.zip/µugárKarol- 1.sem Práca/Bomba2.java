import java.util.Scanner;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.TimeUnit;
import java.io.File;
/**
 * Tato classa generuje zakladne prvky, ktore viem, ze mi bude treba hned na zaciatku
 * to znamena menu prvky - cize obrazky s pozadim
 * a inicializovanie premennych na ich vychodzie nastavenia
 * .
 * 
 * @author Karol Sugar
 * @version 1.1.2022
 */
public class Bomba2 {

    private boolean customMenu;
    private boolean hraBezi;
    private boolean zobrazeneBomby;
    private ArrayList<Vyherca> vyherci;
    private int hlavneMenu;
    private int skoreHry;
    private int napocitanyCas;
    private int indexTlacitka;
    private int power;
    private int uholBomb;
    private Stvorec[] bombyMenu;
    private Obrazok[] obrazok;
    private Mapa2 mapa;
    private Manazer manazer;
    private Scanner terminal;

    private static Bomba2 instance = null;
    private static final int RESETINDEX = 6;
    private Bomba2() {
        
        this.terminal = new Scanner(System.in);
        this.vyherci = new ArrayList<Vyherca>(5);
        this.obrazok = new Obrazok[5];
        this.obrazok[4] = new Obrazok("pics/rectKoniec.png");
        this.obrazok[3] = new Obrazok("pics/rectHowTo.png");
        this.obrazok[2] = new Obrazok("pics/rectVyherci.png");
        this.obrazok[1] = new Obrazok("pics/rectVyberLevel.png");
        this.obrazok[0] = new Obrazok("pics/rectZacniHru.png");
        this.obrazok[4].zmenPolohu(400, 520);
        this.obrazok[3].zmenPolohu(400, 420);
        this.obrazok[2].zmenPolohu(400, 320);
        this.obrazok[1].zmenPolohu(400, 220);
        this.obrazok[0].zmenPolohu(400, 120);
        this.skoreHry = 0;
        this.uholBomb = 0;
        this.power = 0;
        this.napocitanyCas = 0;
        this.hraBezi = false;
        this.zobrazeneBomby = false;
        Obrazok obrazokPozadie = new Obrazok("pics/pozadiePozadia.png");
        obrazokPozadie.zmenPolohu(400, 300);
        obrazokPozadie.zobraz();

    }

    /**
     * touto metodou spustam hru a hned hodim program do hlavneho menu
     *
     */
    public static void spusti() throws FileNotFoundException {
        Bomba2.getInstance().hlavneMenu();
    }

    /**
     * tato metoda zabezpecuje exportovanie do spustitelneho java suboru
     *
     * @param ziadny param
     */
    public static void main(String[] args) throws FileNotFoundException {
        Bomba2.getInstance().hlavneMenu();

    }

    /**
     * Bomba2 singleton - len 1 instancia
     *
     * @return Bomba2 singleton
     */
    private static Bomba2 getInstance() {  //zabranenie, aby sa vytvorilo viacero instancii
        if (Bomba2.instance == null) {    //lebo chcem len 1 hru
            Bomba2.instance = new Bomba2();
        }

        return Bomba2.instance;
    }

    /**
     * Method vymazVsetko
     *tato metoda zabezpecuje zavretie platna
     */
    public void zavriPlatno() {
        Platno canvas = Platno.dajPlatno();
        canvas.zavri();

    }

    /**
     * Method spravujMa
     * Dokaze spravovat sameho seba vdaka manazerovi a this parametru
     */
    public void spravujMa() {
        this.manazer = new Manazer();
        this.manazer.spravujObjekt(this); 
    }

    /**
     * Method vyberMenu
     * tato menu je vyvolana hlavnym menu 
     * vytvori mapy podla zelania
     */
    public void vyberMenu() throws FileNotFoundException {
        this.customMenu = true;
        this.vymazObrazky();
        this.obrazok[0].zmenObrazok("pics/rectPrvyLevel.png");
        this.obrazok[0].zobraz();
        this.obrazok[1].zmenObrazok("pics/rectDruhyLevel.png");
        this.obrazok[1].zobraz();
        this.obrazok[2].zmenObrazok("pics/rectFINAL.png");
        this.obrazok[2].zobraz();
        this.obrazok[3].zmenObrazok("pics/rectNaspat.png");
        this.obrazok[3].zobraz();

        try {
            wait();
        } catch (InterruptedException e) {
        }

        this.vymazObrazky();

        switch (this.indexTlacitka) {
            case 0: 
                MapaLevel prvaMapa = MapaLevel.PRVA;
                this.mapa = Mapa2.generujMapu(prvaMapa);
                this.herneMenu();
                break;

            case 1: 
                MapaLevel druhaMapa = MapaLevel.DRUHA;
                this.mapa = Mapa2.generujMapu(druhaMapa);
                this.herneMenu();
                break;

            case 2:
                MapaLevel finalMapa = MapaLevel.FINAL;
                this.mapa = Mapa2.generujMapu(finalMapa);
                this.herneMenu();
                break;

            case 3:
                this.manazer.prestanSpravovatObjekt(this);
                this.hlavneMenu();
                return;
            default :
                return;

        }

        this.indexTlacitka = this.RESETINDEX;
        this.hraBezi = true;
        this.hlavneMenu(); 
    }

    /**
     * Method vymazObrazky
     * vymazeObrazky - cize menu
     */
    public void vymazObrazky() {
        for (int indexObrazku = 0; indexObrazku < this.obrazok.length;indexObrazku++) {
            this.obrazok[indexObrazku].skry();

        } 

    }

    /**
     * Method addScore
     * zoberie skore z mapy a ulozi si ho tu
     */
    public void addScore() {
        this.skoreHry += this.mapa.getScore();
        this.napocitanyCas += this.mapa.getCas();
    }

    /**
     * Method getCas
     * ziskanie Casu
     * @return The return value
     */
    public int getCas() {
        return this.napocitanyCas;
    }

    /**
     * Method getScore
     * ziskanie Skore
     * @return The return value
     */
    public int getScore() {
        return this.skoreHry;
    }
    
    public void vygenerujBomby() {
        this.bombyMenu = new Stvorec[6];
        this.bombyMenu[0] = new Stvorec(30, 100, 50, 100, 200, 60, 60);
        this.bombyMenu[1] = new Stvorec(30, 400, 100, 200, 200, 60, 60);
        this.bombyMenu[2] = new Stvorec(700, 300, 10, 100, 100, 60, 60);
        this.bombyMenu[3] = new Stvorec(30, 100, 50, 200, 100, 60, 60);
        this.bombyMenu[3].zmenUhol(5, "stred");
        this.bombyMenu[4] = new Stvorec(30, 400, 100, 0, 170, 60, 60);
        this.bombyMenu[4].zmenUhol(5, "stred");
        this.bombyMenu[5] = new Stvorec(700, 300, 10, 50, 180, 60, 60);
        this.bombyMenu[5].zmenUhol(5, "stred");
        this.zobrazeneBomby = true;
        
        for (Stvorec stvorec : this.bombyMenu) {
            stvorec.zobrazMa();
        
        }

    
    }
    
    public void skryBomby() {
        this.zobrazeneBomby = false;
        for (Stvorec stvorec : this.bombyMenu) {
            stvorec.skryMa();
        
        }
    
    }
    
    public void zhorsujBomby() {
        for (Stvorec stvorec : this.bombyMenu) {
            stvorec.zhorsujSa();
            stvorec.zmenUhol(this.uholBomb, "stred");
            this.uholBomb += 20;
                
            if (stvorec.jeCerveny()) {
                stvorec.vynulujMa();
            }
        }
        
            
    }
    
    
    /**
     * Method hlavneMenu
     * hlavne menu, posuva nas z menu do menu, ako hrat hru , ukonci hru a do vyberMenu
     * pouzivam synchronized, nech dokaze cakat pri vytvarani map a nedostanem error concurrent modification, lebo platno nestiha
     */
    public synchronized void hlavneMenu() throws FileNotFoundException {
        Obrazok obrazokNazov = new Obrazok("pics/text82490.png");
        obrazokNazov.zmenPolohu(400, 35);
        obrazokNazov.zobraz();
        
        
        
        
        this.hraBezi = false;
        this.customMenu = false;
        this.spravujMa();
        this.obrazok[0].zmenObrazok("pics/rectZacniHru.png");
        this.obrazok[0].zobraz();
        this.obrazok[1].zmenObrazok("pics/rectVyberLevel.png");
        this.obrazok[1].zobraz();
        this.obrazok[2].zmenObrazok("pics/rectVyherci.png");
        this.obrazok[2].zobraz(); 
        this.obrazok[3].zmenObrazok("pics/rectHowTo.png");
        this.obrazok[3].zobraz(); 
        this.obrazok[4].zmenObrazok("pics/rectKoniec.png");
        this.obrazok[4].zobraz();
        
        this.vygenerujBomby();
        try {
            wait();
        } catch (InterruptedException e) {

        }
        obrazokNazov.skry();
        this.skryBomby();
        switch (this.indexTlacitka) {
            case 0:
                this.vymazObrazky();
                MapaLevel aktMapa = MapaLevel.PRVA;
    
                NekonecnocifernyDisplej displejZobrazSkore = new NekonecnocifernyDisplej(100, 100, 10, 30);
                NekonecnocifernyDisplej displejZobrazMeno = new NekonecnocifernyDisplej(100, 140, 10, 30);
                displejZobrazMeno.setFarbuVsetkych(Farba.CERVENA);
                displejZobrazSkore.setDisplej("potrebny pocet bodov " + aktMapa.getPotrebnyPocetBodov());
                displejZobrazMeno.setDisplej("Mapa   " + aktMapa);
                displejZobrazSkore.zobrazAktualnuHodnotu();
                displejZobrazMeno.zobrazAktualnuHodnotu();
                try {
                    TimeUnit.SECONDS.sleep(2);
                } catch (Exception e) {
                    this.hlavneMenu();
                    return;
                }
                displejZobrazSkore.zhasniVsetky(); 
                displejZobrazMeno.zhasniVsetky(); 
                this.mapa = Mapa2.generujMapu(aktMapa);
    
                this.power = 0;
                this.mapa.setPower(this.power);
                this.herneMenu();
                if (!this.mapa.vyhralSom()) {
                    this.hlavneMenu();
                    return;
                }
                this.addScore();
                if (this.mapa.getCas() > 5) {
                    this.power += 1;
                }
                aktMapa = MapaLevel.DRUHA;
                displejZobrazSkore.setDisplej("potrebny pocet bodov" + aktMapa.getPotrebnyPocetBodov());
                displejZobrazMeno.setDisplej("Mapa   " + aktMapa);
                displejZobrazSkore.zobrazAktualnuHodnotu();
                displejZobrazMeno.zobrazAktualnuHodnotu();
                try {
                    TimeUnit.SECONDS.sleep(2);
                } catch (Exception e) {
                    this.hlavneMenu();
                    return;
                }
                displejZobrazSkore.zhasniVsetky();      
                displejZobrazMeno.zhasniVsetky(); 
                this.mapa = Mapa2.generujMapu(aktMapa);
    
                this.mapa.setPower(this.power);
                this.herneMenu();
                if (!this.mapa.vyhralSom()) {
                    this.hlavneMenu();
                    return;
                }
                this.addScore();
                if (this.mapa.getCas() > 5) {
                    this.power += 1;
                }
                aktMapa = MapaLevel.FINAL;
    
                displejZobrazSkore.setDisplej("potrebny pocet bodov" + aktMapa.getPotrebnyPocetBodov());
                displejZobrazMeno.setDisplej("Mapa   " + aktMapa);
                displejZobrazSkore.zobrazAktualnuHodnotu();
                displejZobrazMeno.zobrazAktualnuHodnotu();
                try {
                    TimeUnit.SECONDS.sleep(2);
                } catch (Exception e) {
                    this.hlavneMenu();
                    return;
                }
                displejZobrazSkore.zhasniVsetky(); 
                displejZobrazMeno.zhasniVsetky(); 
                this.mapa = Mapa2.generujMapu(aktMapa);
    
                this.mapa.setPower(this.power);
                this.herneMenu();
                this.power = 0;
                if (!this.mapa.vyhralSom()) {
                    this.hlavneMenu();
                    return;
                }
                this.addScore();
                this.scoreMenu();
                this.mapa = null;
                this.hlavneMenu();
                break;
            case 1: 
                this.vyberMenu();
                break;
            case 2:
                this.vyherciMenu();
                break;
            case 3:
                this.akoHratMenu();
                this.mapa = null;
                break;
            case 4:
                Platno canvas = Platno.dajPlatno();
                canvas.zavri();
                System.exit(1);
                return;
            default :
                break;

        }

    }

    /**
     * Method akoHratMenu
     * zapne tutorial
     */
    public void akoHratMenu() throws FileNotFoundException {
        this.vymazObrazky();
        this.mapa = Mapa2.generujMapu(MapaLevel.TEST);
        
        this.mapa.prestanSpravovatBomby();
        this.herneMenu();
        this.hlavneMenu();

    }

    /**
     * Method vyherciMenu
     * nacita zo suboru, zoradi podla casu, zobrazi prvych 6 vyhercov cez 16 segmentovy displej, a dokaze ulozit do suboru znova 
     * 
     */
    public void vyherciMenu() throws FileNotFoundException {
        NekonecnocifernyDisplej[] vyhercaMeno = new NekonecnocifernyDisplej[6];
        NekonecnocifernyDisplej[] vyhercaSkore = new NekonecnocifernyDisplej[6];
        NekonecnocifernyDisplej[] vyhercaCas = new NekonecnocifernyDisplej[6];
        this.vymazObrazky();
        this.nacitajVyhercovZoSuboru();
        int x = 0;
        int y = 0;
        int i = 0;
        this.zoradVyhercovPodlaCasu();
        for (Vyherca vyherca: this.vyherci) {
            //Vyherca vyherca = this.vyherci.get(0);
            //int nasobok = 0;
            if (i == 6) {
                break;
            }
            vyhercaMeno[i] = new NekonecnocifernyDisplej(x + 20, y + 20, 20, 6);
            vyhercaMeno[i].setDisplej(vyherca.getMeno());
            vyhercaMeno[i].zobrazAktualnuHodnotu();
            vyhercaSkore[i] = new NekonecnocifernyDisplej(x + 200, y + 20, 20, 6);
            vyhercaSkore[i].setDisplej(vyherca.getSkore());
            vyhercaSkore[i].zobrazAktualnuHodnotu();
            vyhercaCas[i] = new NekonecnocifernyDisplej(x + 380, y + 20, 20, 6);
            vyhercaCas[i].setDisplej(vyherca.getCas());
            vyhercaCas[i].zobrazAktualnuHodnotu(); 
            if (i == 0) {
                vyhercaMeno[i].setFarbuVsetkych(Farba.MODRA);
                vyhercaSkore[i].setFarbuVsetkych(Farba.MODRA);
                vyhercaCas[i].setFarbuVsetkych(Farba.MODRA);
            }
            y += 60;
            i += 1;
        }
        this.obrazok[3].zmenObrazok("pics/rectNaspat.png");
        this.obrazok[3].zobraz();
        this.obrazok[4].zmenObrazok("pics/rectUlozVyhercov.png");
        this.obrazok[4].zobraz();

        try {
            wait();
        } catch (InterruptedException e) {

        }
        i = 0;
        for (Vyherca vyherca: this.vyherci) {
            //Vyherca vyherca = this.vyherci.get(0);
            //int nasobok = 0;

            if (i == 6) {
                break;
            }

            vyhercaMeno[i].zhasniVsetky();
            vyhercaMeno[i] = null;
            vyhercaSkore[i].zhasniVsetky();
            vyhercaSkore[i] = null;
            vyhercaCas[i].zhasniVsetky();
            vyhercaCas[i] = null;
            i += 1;
        }  

        switch (this.indexTlacitka) {
            case 3: 
                this.manazer.prestanSpravovatObjekt(this);
                this.hlavneMenu();
                break;
            case 4: 
                this.ulozVyhercovDoSuboru();
                this.manazer.prestanSpravovatObjekt(this);
                this.hlavneMenu();
                break;
        }
    }

    /**
     * Method scoreMenu
     * ukaze terminal so skore, a ci si ho chce ulozit
     */
    public void scoreMenu()  throws FileNotFoundException {
        String volba;

        System.out.print('\u000C'); //system.out.clear
        System.out.println("Score menu");
        System.out.println("tvoje score :" + this.getScore());
        System.out.println("tvoj cas " + this.getCas());
        System.out.println("napis U - na ulozenie score");
        System.out.println("napis B - pre vratenie sa do menu");

        volba = this.terminal.next();
        switch (volba) {
            case "B":
                break;
            case "U":
                this.scoreUkladanieMenu();
                break;
            default:
                return;
        }
        System.out.print('\u000C'); //system.out.clear

    }

    /**
     * Method zoradVyhercovPodlaCasu
     * zoradenie, zdroj javaDocs 
     */
    public void zoradVyhercovPodlaCasu() {
        Collections.sort(this.vyherci);
    }

    /**
     * Method pridajVyhercu
     * prida vyhercu a ulozi jeho skore
     * ak je lepsi, ako 6 hrac, ulozi uz zoradenych do suboru
     * 
     * @param meno A parameter
     * @param skore A parameter
     * @param cas A parameter
     * @return True alebo False pri porovnavani, ci je dobry alebo zly
     */
    public boolean pridajVyhercu(String meno, int skore, int cas) {
        if (this.vyherci.size() < 6) {
            this.vyherci.add(new Vyherca(meno, skore, cas));
            return true;
        }
        this.vyherci.add(new Vyherca(meno, skore, cas));
        Vyherca posledny = this.vyherci.get(5);
        if (posledny.getCas() >= cas) {

            try {
                this.ulozVyhercovDoSuboru();
            } catch (Exception e) {

            }
            return true;
        }
        return false;
    }

    /**
     * Method scoreUkladanieMenu
     * ulozenie skore a urcenie, ci je hodny na tabulu vitazov
     */
    public void scoreUkladanieMenu()  throws FileNotFoundException {
        System.out.println("Ukladanie Score");
        System.out.println("napis svoje meno");
        System.out.println("tvoje score " + this.getScore());
        System.out.println("tvoj cas " + this.getCas());
        String meno = this.terminal.next();
        System.out.print('\u000C');
        this.nacitajVyhercovZoSuboru();
        this.zoradVyhercovPodlaCasu();
        if (this.pridajVyhercu(meno, this.getScore(), this.getCas())) {
            System.out.println("ukladam ta ako " + meno + " so skore: " + this.getScore());
            System.out.println("cas: " + this.getCas());
            System.out.println("a budes na tabuli vyhercov");

        } else {
            System.out.println("ukladam ta ako " + meno + " so skore: " + this.getScore());
            System.out.println("cas: " + this.getCas());
            System.out.println("ale nebudes na tabuli vyhercov");
        } 
        this.zoradVyhercovPodlaCasu();
        this.ulozVyhercovDoSuboru();
        this.napocitanyCas = 0;
        System.out.println("");
        System.out.println("za par sekund ta presmerujem do menu..");
        System.out.println("za par sekund ta presmerujem do menu..");

        try {
            TimeUnit.SECONDS.sleep(9);
        } catch (Exception e) {
            this.hlavneMenu();
            return;
        }

        System.out.print('\u000C');

    }

    /**
     * Method ulozVyhercovDoSuboru
     * ulozi vyhercov do suboru BombaVyhercovia.txt
     */
    public void ulozVyhercovDoSuboru() throws FileNotFoundException {

        File subor = new File("BombaVyhercovia.txt");
        PrintWriter zapisovac = new PrintWriter(subor);

        for (Vyherca vyherca : this.vyherci) {
            zapisovac.println(vyherca.getMeno() + " " + vyherca.getSkore() + " " + vyherca.getCas());
        } 
        zapisovac.close();
    }

    /**
     * Method nacitajVyhercovZoSuboru
     * nacita vyhercov zo suboru BombaVyhercovia.txt
     */
    public void nacitajVyhercovZoSuboru() throws FileNotFoundException {

        File subor = new File("BombaVyhercovia.txt");
        Scanner citac = new Scanner(subor);

        this.vyherci.clear(); 
        while (citac.hasNext()) {
            String meno = citac.next();
            int skore = citac.nextInt();
            int cas = citac.nextInt();
            this.vyherci.add(new Vyherca(meno, skore, cas));
        }
        citac.close();
    }

    /**
     * Method herneMenu
     * herne menu, sluzi na prepinanie medzi menu a hrou samotnou
     * pouzivam terminal a scanner - pouzite zo sokobana
     */
    public void herneMenu()  throws FileNotFoundException {
        String volba;
        this.manazer.prestanSpravovatObjekt(this);
        do {
            System.out.println("Herne menu");
            if (this.customMenu) {
                System.out.println("napis B - na vratenie sa menu"); 
            } else if (this.mapa.getNazovMapy().equals("Test")) {
                System.out.print('\u000C');
                Platno platno = Platno.dajPlatno();
                platno.zavri();
                System.err.println("tutorial "); 
                System.out.println("Tento terminal sluzi na presuvanie sa ");  
                System.out.println("medzi Menu a Hrou samotnou ");
                System.out.println("---------");

                try {
                    TimeUnit.SECONDS.sleep(7);
                } catch (Exception e) {
                    this.hlavneMenu();
                    return;
                }

                System.out.println("Príklady terminalovej správy počas hry: ");
                System.out.println("Napis B - na pokracovanie na dalsiu mapu");
                System.out.println("Napis B - na vratenie sa menu");

                try {
                    TimeUnit.SECONDS.sleep(7);
                } catch (Exception e) {
                    this.hlavneMenu();
                    return;
                }
                System.out.print('\u000C');
                System.out.println("Podme sa pozriet do okna hry");
                System.out.println("Otvorim ti okno hry a zapnem sprievodcu");
                try {
                    TimeUnit.SECONDS.sleep(7);
                } catch (Exception e) {
                    this.hlavneMenu();
                    return;
                }
                Platno.dajPlatno();
                System.out.println("Pre ukoncenie tutorialu zadaj B");
                Platno.dajPlatno();
                this.mapa.zapniTutorial();

            } else {
                System.out.println("napis B - na pokracovanie na dalsiu mapu");
            }
            volba = this.terminal.next();
            switch (volba) {
                case "B":
                    break;
                default:
                    return;

            }
        } while (!volba.equals("B"));
        this.mapa.vymazVsetko();
        this.mapa.skryZaverecnyObrazok();
        this.mapa.prestanSpravovatBomby();

        System.out.print('\u000C'); //system.out.clear

    }

    public void tik() {
        if (this.zobrazeneBomby) {
            this.zhorsujBomby();
        }
    }

    /**
     * Method setKliknutyObrazok
     * ked kliknem na obrazok ulozi indexObrazku, na ktory som klikol a odomkne thready hlavnehoMenu alebo vyberMenu 
     * @param indexObrazku A parameter
     */
    public synchronized void setKliknutyObrazok(int indexObrazku) {
        this.indexTlacitka = indexObrazku;
        //this.klikTlacitko=true;
        notifyAll();

    }

    /**
     * Method vyberSuradnice
     * pouzivam menezera na zistovanie, kde som klikol
     * @param x A parameter
     * @param y A parameter
     */
    public void vyberSuradnice(int x, int y) {   //vyberiem suradnice a skontrolujem vo foreach
        for (int indexObrazku = 0; indexObrazku < this.obrazok.length; indexObrazku++) {
            int[] suradniceObrazku = this.obrazok[indexObrazku].getSuradnice(); //prve x , druhe y
            int[] rozmeryObrazku = this.obrazok[indexObrazku].getRozmery(); //prva sirka, druhe sirka

            if ((x >= suradniceObrazku[0]) && (x <= suradniceObrazku[0] + rozmeryObrazku[0]) && 
                (y >= suradniceObrazku[1]) && (y <= suradniceObrazku[1] + rozmeryObrazku[1]) && (this.obrazok[indexObrazku].getViditelny())) {
                this.setKliknutyObrazok(indexObrazku);
                return;

            } 

        }

    }   
}
