
/**
 * Write a description of class Vyherci here.
 * Obalovacia trieda, aby som niekde ukladal informacie o vyhercovi pekne priehladne
 * pouzivam Comparable, aby som potom vedel zoradit vyhercov podla casu , kedze v tejto hre ide len o cas
 * @author Karol S.
 * @version 1.1.2022
 */
public class Vyherca implements Comparable<Vyherca> {
    private String meno;
    private int skore;
    private int cas;
    public Vyherca(String meno, int skore, int cas) {
        this.meno = meno.toUpperCase();
        this.skore = skore;
        this.cas = cas;
    }
    
    /**
     * Method getMeno
     * ziskam meno vyhercu
     * @return The return value
     */
    public String getMeno() {
        return this.meno;
    }
    
    /**
     * Method getSkore
     * ziskam skore vyhercu
     * @return The return value
     */
    public int getSkore() {
        return this.skore;
    }
    
    /**
     * Method getCas
     * ziskam cas vyhercu
     * @return The return value
     */
    public int getCas() {
        return this.cas;
    }
    
    /**
     * Method compareTo , skopirovane z netu
     *
     * @param zabalena trieda vyhercu
     * @return rozdiel
     */
    @Override
    public int compareTo(Vyherca porovnavanieVitaza) {
        int porovnajCas = ((Vyherca)porovnavanieVitaza).getCas();
        return this.cas - porovnajCas;

        /* For Descending order do like this */
        //return compareage-this.studentage;
    }

    
    
    
    
}
