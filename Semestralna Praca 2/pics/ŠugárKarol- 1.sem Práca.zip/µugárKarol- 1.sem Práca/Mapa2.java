import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.TimeUnit;
public class Mapa2 {
    private ArrayList<Stvorec> balikBomb;
    private Random random;
    private Platno canvas;
    private Manazer manazer;
    private String menoMapy;
    private int mapaScore;
    private int obtiaznost;
    private Background background;
    private int potrebnyPocetSkore;
    private int rychlost;
    private int cas;
    private boolean vyhralSom = false;
    private Obrazok zaverecnyObrazok;
    private boolean beziHra;
    private boolean kruhIsActive = false;
    private Kruh kruh;
    private static final int SIRKA_PLATNA = Platno.dajPlatno().getSirkaPlatna();
    private static final int VYSKA_PLATNA = Platno.dajPlatno().getVyskaPlatna();
    private static final int VYSKA_PRVKOV = 72;
    private static int stranaB = 60;
    private static int stranaA = 60;

    /**
     * Mapa2 Constructor
     * Mapa vytvori bomby, pri vytvarani hlada prazdne policka cez algoritmus 
     * random RGB s tym, ze red nesmie byt viac ako 100
     * s mapou sa vytvori background, random a manazer, ktory spravuje bomby a kde som klikol
     * poslem mu MapaLevel a on si z nej vytiahne potrebne veci
     * je private, pouzivam public static vytvor mapu na vytvorenie instancie mapy
     * @param mapaLevel A parameter
     */
    private Mapa2(MapaLevel mapaLevel) {
        this.menoMapy = mapaLevel.getNazov();
        this.potrebnyPocetSkore = mapaLevel.getPotrebnyPocetBodov();
        int pocetBomb = mapaLevel.getPocetBomb();
        this.balikBomb = new ArrayList<Stvorec>();
        this.random = new Random();
        this.manazer = new Manazer();

        // this.zaverecnyObrazok = new Obrazok("pics/bRectBlank.png");
        // this.zaverecnyObrazok.zmenPolohu(this.SIRKA_PLATNA / 2, this.VYSKA_PLATNA / 2);
        // this.zaverecnyObrazok.skry();
        this.cas = mapaLevel.getCas();
        this.background = new Background(100, mapaLevel.getPowerMax(), this.cas);

        //generovanie bomb na prazdnom mieste
        int xBomby = this.random.nextInt(SIRKA_PLATNA - stranaA );
        int yBomby = this.random.nextInt(VYSKA_PLATNA - stranaB );
        for (int indexBomby = 0; indexBomby < pocetBomb; indexBomby++) {
            boolean jeTamInyObjekt = true; 
            int[] suradnicePrazdnehoMiesta = this.najdiPrazdneMiesto();
            this.balikBomb.add(new Stvorec(suradnicePrazdnehoMiesta[0], suradnicePrazdnehoMiesta[1], 
                    this.random.nextInt(100), this.random.nextInt(256), this.random.nextInt(256), this.stranaA, this.stranaB));

            //Stvorec novyStvorec = new Stvorec(xBomby,yBomby,
            //this.random.nextInt(100),this.random.nextInt(256),this.random.nextInt(256),stranaA,stranaB);
            //this.balikBomb.get(indexBomby).setMiesto(suradnicePrazdnehoMiesta[0],suradnicePrazdnehoMiesta[1]);
            this.balikBomb.get(indexBomby).zobrazMa();

        }

        //vytvorenie background prvkov
        //mapa spravuje bomby 
        this.zacniSpravovatBomby(); 
        this.beziHra = true;

    }
    
    /**
     * Method generujTutorial
     * vygeneruje tutorial mapu
     * @return The return value
     */
    public static Mapa2 generujTutorial() {
        Mapa2 mapa = new Mapa2 (MapaLevel.TEST);
        return mapa;
    }
    
    /**
     * Method generujMapu
     * vygeneruje moju zadanu mapu
     * @param mapaLevel A parameter
     * @return The return value
     */
    public static Mapa2 generujMapu(MapaLevel mapaLevel) {
        Mapa2 mapa = new Mapa2 (mapaLevel);
        return mapa;
    }
    
    
    /**
     * Method getNazovMapy
     * ziskam meno mapy
     * @return The return value
     */
    public String getNazovMapy() {
        return this.menoMapy;
    }

    /**
     * Method vytvorZaverecnyObrazok
     * vytvori zaverecny obrazok, bud vyhral alebo prehral
     * @param cesta A parameter
     */
    public void vytvorZaverecnyObrazok(String cesta) {
        this.zaverecnyObrazok = new Obrazok(cesta);
        this.zaverecnyObrazok.zmenPolohu(this.SIRKA_PLATNA / 2, this.VYSKA_PLATNA / 2);

    }

    /**
     * Method vyhral
     * ak vyhral, ukonci hru , vypusti menezera a vytvori obrazok
     */
    public void vyhral() {
        //this.vymazVsetko();
        this.manazer.prestanSpravovatObjekt(this);
        this.vytvorZaverecnyObrazok("pics/rectVyhra.png");
        this.zaverecnyObrazok.zobraz();
        this.beziHra = false;
        this.vyhralSom = true;

    }
    
    /**
     * Method prehral
     *ak prehral, ukonci hru , vypusti menezera a vytvori obrazok
     */
    public void prehral() {
        this.vymazVsetko();

        this.manazer.prestanSpravovatObjekt(this);
        this.vytvorZaverecnyObrazok("pics/rectPrehra.png");        
        this.beziHra = false;
        this.vyhralSom = false;
        this.zaverecnyObrazok.zobraz();

    }

    /**
     * Method zapniTutorial
     * zapne tutorial a vysvetluje, ako funguje hra
     */
    public void zapniTutorial() {
        this.prestanSpravovatBomby();
        Stvorec tutorialBomba = new Stvorec(500, 400, 150, 150, 150, this.stranaA, this.stranaB);

        NekonecnocifernyDisplej dialog = new NekonecnocifernyDisplej(20, 100, 10, 41);
        NekonecnocifernyDisplej dialog2 = new NekonecnocifernyDisplej(20, 200, 10, 40);
        dialog.setDisplej("Ahoj Ja som tvoj sprievodca");
        dialog.zobrazAktualnuHodnotu();
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (Exception e) {

            return;
        }
        dialog.setDisplej("Toto je bomba");
        tutorialBomba.zobrazMa();
        dialog2.setDisplej("Bomba moze byt gulata a stvorcova");
        this.vygenerujKruhovuBombu();
        dialog2.zobrazAktualnuHodnotu();
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (Exception e) {

            return;
        }
        this.kruh.skry();
        dialog.setDisplej("Stvorcova mozes kliknut len ak je cervena");
        dialog2.setDisplej("Cim cervensia tym lepsie skore");       
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (Exception e) {

            return;
        }       
        tutorialBomba.skryMa();
        this.kruh.zobraz();
        dialog.setDisplej("Okruhlu bombu musis kliknut do sekundy");
        dialog2.setDisplej("Gulata meni nahodne farby a generuje sa v nahodny cas");         
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (Exception e) {

            return;
        }        
        this.kruh.skry();
        dialog.setDisplej("Teraz zapnem mapu");
        dialog2.setDisplej("Stikni na stvorec ked bude cerveny"); 
        //tutorialBomba.setViditelnost(true);
        tutorialBomba.zobrazMa();
        

        this.manazer.spravujObjekt(tutorialBomba);
        do {

            try {
                TimeUnit.SECONDS.sleep(15);
            } catch (Exception e) {

                return;
            }
            if (!tutorialBomba.somVybuchnuty()) {
                break;
            }    

            dialog.setDisplej("Bomba ti vybuchla");
            dialog2.setDisplej("zapinam opat bombu");
            tutorialBomba.vynulujBumDisplej();
            tutorialBomba.vynulujMa();

        } while (!tutorialBomba.somVybuchnuty()) ; 
        this.manazer.prestanSpravovatObjekt(tutorialBomba);
        tutorialBomba.skryMa();
        int score = tutorialBomba.pickScore();
        this.pridajMapoveSkore(score);
        dialog.setDisplej("Super pripocitalo sa ti " + score + " skore");
        dialog2.setDisplej("mozes ziskat 100 alebo 300");

        tutorialBomba.skryMa();
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (Exception e) {

            return;
        }
        dialog.setDisplej("zalezi ako blizko si bol k cervenej");
        dialog2.setDisplej("cim cervensia tym lepsie skore");

        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (Exception e) {

            return;
        }
        dialog.setDisplej("Super teraz dame okruhlu bombu");
        dialog2.setDisplej("stikni co najrychlejsie ");

        this.vygenerujKruhovuBombu(); 
        this.manazer.spravujObjekt(this.kruh);
        do {
            this.kruh.zobraz();

            try {
                TimeUnit.SECONDS.sleep(5);
            } catch (Exception e) {

                return;
            }
            if (!this.kruh.getVybuchni()) {
                break;
            }     

            dialog.setDisplej("Bomba ti vybuchla");
            dialog2.setDisplej("zapinam opat bombu"); 
            this.kruh.setVybuchni(false);
            this.kruh.zresetujPocitadlo();
        } while (!this.kruh.getVybuchni()) ; 
        this.manazer.prestanSpravovatObjekt(this.kruh);
        dialog.setDisplej("Super uz vies ako klikat");
        dialog2.setDisplej("este ohladom zivotov ti nieco poviem"); 
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (Exception e) {

            return;
        }
        dialog.setDisplej("extra HP   cize power sa ti pripocita");
        dialog2.setDisplej("ak skoncis mapu  5 sekund skor");  
        
        
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (Exception e) {

            return;
        }
        dialog2.setDisplej("");
        dialog.setDisplej("power sa ti prenasa medzi levelami");
        
        try {
            TimeUnit.SECONDS.sleep(5);
        } catch (Exception e) {

            return;
        }
        dialog.setDisplej("power sa ti pripocita dole do HUD");
        dialog2.setDisplej("ukazem ti nazorny priklad"); 
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (Exception e) {

            return;
        }
        this.background.pridajPower();
        dialog.setDisplej("ako vidis mas jeden power");
        dialog2.setDisplej("ak netrafis bombu najprv sa ti odcitava power");
        tutorialBomba.setViditelnost(true);
        tutorialBomba.vybuchni();
        this.background.odoberPower();
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (Exception e) {

            return;
        }

        dialog.setDisplej("a ked nebudes mat uz power");
        dialog2.setDisplej("tak sa ti budu odpocitavat HP");
        tutorialBomba.vybuchni();
        this.background.odcitajHP(25);
        try {
            TimeUnit.SECONDS.sleep(2);
        } catch (Exception e) {

            return;
        }

        dialog.setDisplej("Parada to je vsetko");
        dialog2.setDisplej("uz vies ako hrat"); 
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (Exception e) {

            return;
        }
        this.background.odoberPower();
        dialog.setDisplej("Do terminalu napis B");  
        dialog2.setDisplej("a drzim palce"); 
        try {
            TimeUnit.SECONDS.sleep(3);
        } catch (Exception e) {

            return;
        }
        dialog.zhasniVsetky();
        dialog2.zhasniVsetky();
        dialog = null;
        dialog2 = null;
        tutorialBomba.skryMa();
        tutorialBomba = null;
        this.vymazVsetko();
    }

    /**
     * Method vymazVsetko
     * vymaze vsetko od displejov, backgroundu az po kruhy a stvorce
     */
    public void vymazVsetko() {
        for (Stvorec bomba : this.balikBomb) {
            bomba.skryMa();

        }
        this.background.vymazDispleje();
        this.kruh = Kruh.getInstance();
        this.kruh.skry();
        return;
    }

    /**
     * Method beziHra
     * pytam sa , ci bezi hra
     * @return The return value
     */
    public boolean beziHra() {
        return this.beziHra;
    }

    /**
     * Method vyhralSom
     * pytam sa , ci som vyhral
     * @return The return value
     */
    public boolean vyhralSom() {
        return this.vyhralSom;
    }

    /**
     * Method getScore
     * pytam si skore z aktualnej mapy
     * @return The return value
     */
    public int getScore() {
        return this.mapaScore;
    }

    /**
     * Method getCas
     * pytam si cas v tomto momente
     * @return The return value
     */
    public int getCas() {
        return (this.background.getCas());
    }

    /**
     * Method setPower
     * pridavam power
     * @param powerSet A parameter
     */
    public void setPower(int powerSet) {

        for (int i = 0; i < powerSet; i++) {
            this.background.pridajPower();
        }
    }

    /**
     * Method skryZaverecnyObrazok
     * skryje zaverecny obrazok
     */
    public void skryZaverecnyObrazok() {
        if (!this.beziHra()) {
            this.zaverecnyObrazok.skry();
        }
    }

    /**
     * Method getExtraCas
     * zoberie si, kolko este ostavalo casu- na urcenie bonusu na power
     * @return The return value
     */
    public int getExtraCas() {
        return this.cas - this.background.getCas();
    }

    /**
     * Method najdiPrazdneMiesto
     * hlada prazdne miesto , kde polozi bombu
     * nasledne posle suradnice prazdneho miesta
     * @return The return value
     */
    private int[] najdiPrazdneMiesto() {
        int xBomby ;
        int yBomby ;
        boolean jeTamInyObjekt = false; 
        do { 
            xBomby = this.random.nextInt(SIRKA_PLATNA - stranaA);
            yBomby = this.random.nextInt(VYSKA_PLATNA - VYSKA_PRVKOV * 3) + VYSKA_PRVKOV;
            jeTamInyObjekt = false;
            for (Stvorec bomba: this.balikBomb) {

                if (bomba.somTam(xBomby, yBomby) || (bomba.somTam(xBomby + stranaA, yBomby + stranaB)) ||
                    (bomba.somTam(xBomby + stranaA, yBomby)) || (bomba.somTam(xBomby, yBomby + stranaB))) {
                    jeTamInyObjekt = true;
                }

            }

        } while (jeTamInyObjekt);   

        int[] suradnicePrazdnehoMiesta = {xBomby, yBomby};
        return suradnicePrazdnehoMiesta;

    }

    /**
     * Method zacniSpravovatBomby
     *spravuje bomby, tikaju
     */
    public void zacniSpravovatBomby () {
        this.manazer.spravujObjekt(this);
    }

    
    /**
     * Method prestanSpravovatBomby
     * prestal spravovat bomby, netikaju
     */
    public void prestanSpravovatBomby () {
        this.manazer.prestanSpravovatObjekt(this);
    }

    /**
     * Method setMapoveSkore
     * nastavim skore mapy
     * @param skore A parameter
     */
    public void setMapoveSkore(int skore) {
        this.mapaScore = skore;
    }

    /**
     * Method pridajMapoveSkore
     * pridam do mapaScore hodnoty a urcujem, ci vyhral
     * @param skore A parameter
     */
    public void pridajMapoveSkore(int skore) {

        this.mapaScore += skore;
        this.background.setSkore(this.mapaScore);
        if (skore == 0 && (!this.background.odcitajHP(25))) {
            this.prehral();
        }
        if (this.mapaScore >= this.potrebnyPocetSkore ) {
            this.vyhral();
            this.getCas();
        }

    } 

    /**
     * Method vygenerujKruhovuBombu
     * vygeneruje jednu kruhovu bombu
     */
    public void vygenerujKruhovuBombu() {
        int[] suradnicePrazdnehoMiesta = this.najdiPrazdneMiesto();
        this.kruh = Kruh.getInstance();
        this.kruh.setVybuchni(false);
        this.kruh.zmenPolohu(suradnicePrazdnehoMiesta[0], suradnicePrazdnehoMiesta[1]);
        this.kruh.zobraz();
        this.kruh.zresetujPocitadlo();
        this.kruhIsActive = true;

        
    
    }
    /**
     * Method tik
     * pri kazdom tiku odcita sekundu z backgroundu , ak sa uz neda, prehral
     * pri kazdom tiku generuje s 1:20 sancou kruhovu bombu
     * pri kazdom tiku zistuje, ci nejaka bomba vybuchne a aj zcervenava ich
     */
    public void tik() {
        if (!this.background.odcitajSekundu()) {
            this.prehral();
        }

        int randomInt = this.random.nextInt(20);
        if (randomInt == 3) {
            this.vygenerujKruhovuBombu();
        }

        if ((this.kruhIsActive) && (this.kruh.jeViditelny()) && (!this.kruh.getVybuchni())) {
            this.kruh.tik();
            if (this.kruh.getVybuchni()) {
                this.kruh.skry();
                this.kruhIsActive = false;
                this.kruh = null;
                if (!this.background.odcitajHP(25)) {
                    this.prehral();
                }
            }
        }

        for (Stvorec  bomba : this.balikBomb) {
            if (!bomba.somVybuchnuty()) {
                bomba.tik();    
                if (bomba.somVybuchnuty()) {

                    if (!this.background.odcitajHP(25)) {
                        this.prehral();
                    }
                }   
            }

        }

    }

    
    /**
     * Method vyberSuradnice
     * zistuje, kde som klikol a pri trafeni bomby prida skore , ktore si bomba urcila za vhodne
     * @param x A parameter
     * @param y A parameter
     */
    public void vyberSuradnice(int x, int y) {
        if ((this.kruhIsActive) && (this.kruh.somTam(x, y)) && (!this.kruh.getVybuchni())) {

            this.pridajMapoveSkore(this.kruh.getScoreKruhu());
            this.kruhIsActive = false;
            this.kruh.skry();
            this.kruh = null;
        }

        
        for (Stvorec  bomba : this.balikBomb) {

            if ((!bomba.somVybuchnuty()) && (bomba.somTam(x, y))) {

                bomba.pridajScore();
                int skoreBomby = bomba.pickScore();
                //bomba.vynulujMa();
                this.pridajMapoveSkore(skoreBomby);   
            }        
        }

    }
}
