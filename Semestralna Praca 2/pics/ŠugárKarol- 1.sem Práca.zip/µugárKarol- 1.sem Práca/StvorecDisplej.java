import java.awt.Rectangle;

/**
* skopirovane z cviceni , pridana RGB funkcia a zmena uhla a farby
*/

public class StvorecDisplej {
    private int x;
    private int y;
    private int stranaA;
    private int stranaB;
    private Uhol uhol;
    private int r;
    private int g;
    private int b;
    private boolean jeViditelny;
    
    public StvorecDisplej(int x, int y, Farba farba, int stranaA, int stranaB) {
        this.x = x;   //tieto bud budu random, alebo staticke, este uvidim. 
        this.y = y;    //Alebo bude staticke a potom dynamicke aj sandbox verzia.
        this.stranaA = stranaA;
        this.stranaB = stranaB;
        this.r = farba.getR();
        this.g = farba.getG();
        this.b = farba.getB();
        this.jeViditelny = false;
        this.uhol = new Uhol(0, this.x, this.y);
    }

    public void nakresliMaRGB() { 
        if (!this.jeViditelny()) {
            return;
        }
        Platno canvas = Platno.dajPlatno();
        this.r = r;
        this.g = g;
        this.b = b;
        canvas.wait(2);
        canvas.drawRGB(this, this.r, this.g, this.b,
            new Rectangle(this.x, this.y, this.stranaA, this.stranaB), this.uhol);
       
        this.jeViditelny = true;

    }      
    
    
    public void skryMa() {
        this.zmaz();
        this.jeViditelny = false;
    }
    
    public boolean jeViditelny() {
        return this.jeViditelny;
    }
    
    public void setMiesto(int x, int y) {
        this.x = x;
        this.y = y;
        this.nakresliMaRGB();
    }
    
    public void zmenUhol(int uhol, String miestoKotvy) {
    
        switch (miestoKotvy) {
            case "stred":
                this.uhol = new Uhol(uhol, this.x + this.x / 2, this.y + this.y / 2);
                break;
            case "zaciatok":
                this.uhol = new Uhol(uhol, this.x, this.y);
                break;
            default:
                this.uhol = new Uhol(uhol, this.x, this.y);
        }
        this.nakresliMaRGB();
    }
    
    public void zmenFarbu(Farba farba) {
        int[] farbaArray = farba.getRGB();
        this.r = farbaArray[0];
        this.g = farbaArray[1]; 
        this.b = farbaArray[2];
        
        if (this.jeViditelny()) {
            this.nakresliMaRGB();
        }
    }
    
    public void zobrazMa() {
        this.jeViditelny = true;
        this.nakresliMaRGB();
    }
    
    public void zmaz() {
        if (this.jeViditelny) {
            Platno canvas = Platno.dajPlatno();
            canvas.erase(this);
        }
    }
    
    
    
    
   

}
  

