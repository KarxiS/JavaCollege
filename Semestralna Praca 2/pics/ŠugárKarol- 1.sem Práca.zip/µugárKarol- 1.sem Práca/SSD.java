import java.util.ArrayList;
import java.util.List;
/**
 * Zo 7 segmentoveho cisla/slova som spravil 16 segmentovy, bocnice , sikme segmenty vykreslujem cez Uhol classu a vypocitavam cez tangensy
 * pridana podpora slov a pismen, aj dlzen
 * pridane automaticke vypocitavanie aj dlzky sikmych segmentov cez pytagorovu vetu, cize pri roznej sirke, vyske bude pekne posluchat 
 * @author Prezencne cvicenia + Karol S.
 * @version 1.1.2022
 */
public class SSD {
    private Segment segment; 
    private Segment a1;
    private Segment a2;
    private Segment b; 
    private Segment c; 
    private Segment d1;
    private Segment d2;
    private Segment e; 
    private Segment f; 
    private Segment g1;
    private Segment g2;
    private Segment h;
    private Segment i;
    private Segment j;
    private Segment k;
    private Segment l;
    private Segment m;
    private Segment dlzenSeg;
    private boolean dlzenStat;
    private boolean somViditelny;
    private int x;
    private int y;
    private int sirkaPolCelehoSSD;
    private List<Segment> segmentList;
    private static int vyskaDelitel = 20;
    private static int sirkaDelitel = 5;
    /**
     * Constructor for objects of class SSD   
     * inicializujem kazdy segment, vypocitavam cez tangens vypocitavam uhol sikmych segmentov a dlzku cez pytagorovu vetu  
     * ulozim si x y
     * 
     */
    public SSD(int x, int y, Farba farba, int sirkaCelehoSSD, int vyskaCelehoSSD) {
        this.segmentList = new ArrayList<>();
        this.sirkaPolCelehoSSD = sirkaCelehoSSD / 2;
        int uholKrizovych = ((int)Math.toDegrees(Math.atan((double)sirkaCelehoSSD / vyskaCelehoSSD)) - 2) ;
        int sirkaSegmentu = sirkaCelehoSSD / sirkaDelitel;
        int vyskaSegmentu = vyskaCelehoSSD / vyskaDelitel;
        int dlzkaKrizovych =  (int)((Math.sqrt((Math.pow((double)sirkaCelehoSSD, 2) + Math.pow((double)sirkaCelehoSSD, 2)))) - sirkaSegmentu * 2);
        this.a1 = new Segment(x, y, farba, sirkaCelehoSSD / 2 , vyskaCelehoSSD / vyskaDelitel);
        this.segmentList.add(this.a1);
        this.a2 = new Segment(x + sirkaCelehoSSD / 2, y, farba, sirkaCelehoSSD / 2, vyskaCelehoSSD / vyskaDelitel );
        this.segmentList.add(this.a2);
        this.b = new Segment(x + sirkaCelehoSSD, y, farba, sirkaCelehoSSD / sirkaDelitel, vyskaCelehoSSD / 2 );
        this.segmentList.add(this.b);
        this.c = new Segment(x + sirkaCelehoSSD, y + vyskaCelehoSSD / 2, farba, sirkaCelehoSSD / sirkaDelitel, vyskaCelehoSSD / 2 + sirkaSegmentu / 2);
        this.segmentList.add(this.c);
        this.d1 = new Segment(x, y + vyskaCelehoSSD, farba, sirkaCelehoSSD / 2, vyskaCelehoSSD / vyskaDelitel);
        this.segmentList.add(this.d1);
        this.d2 = new Segment(x + sirkaCelehoSSD / 2, y + vyskaCelehoSSD, farba, sirkaCelehoSSD / 2, vyskaCelehoSSD / vyskaDelitel);
        this.segmentList.add(this.d2);
        this.e = new Segment(x, y + vyskaCelehoSSD / 2, farba, sirkaCelehoSSD / sirkaDelitel, vyskaCelehoSSD / 2);
        this.segmentList.add(this.e);
        this.f = new Segment(x, y, farba, sirkaCelehoSSD / sirkaDelitel, vyskaCelehoSSD / 2);
        this.segmentList.add(this.f);
        this.g1 = new Segment(x, y + vyskaCelehoSSD / 2, farba, sirkaCelehoSSD / 2, vyskaCelehoSSD / vyskaDelitel);
        this.segmentList.add(this.g1);
        this.g2 = new Segment(x + sirkaCelehoSSD / 2, y + vyskaCelehoSSD / 2, farba, sirkaCelehoSSD / 2, vyskaCelehoSSD / vyskaDelitel);
        this.segmentList.add(this.g2);
        this.h = new Segment(x + sirkaSegmentu / 2, y + sirkaSegmentu / 2, farba, sirkaCelehoSSD / sirkaDelitel, dlzkaKrizovych);
        this.h.zmenUhol(-uholKrizovych);
        this.segmentList.add(this.h);     
        this.i = new Segment(x + sirkaCelehoSSD / 2, y,  farba, sirkaCelehoSSD / sirkaDelitel, vyskaCelehoSSD / 2);       
        this.segmentList.add(this.i); 
        this.j = new Segment(x + sirkaCelehoSSD - sirkaSegmentu / 2, y, farba, sirkaCelehoSSD / sirkaDelitel, dlzkaKrizovych);
        this.j.zmenUhol(uholKrizovych);
        this.segmentList.add(this.j);
        this.m = new Segment(x + sirkaCelehoSSD / 2, y + vyskaCelehoSSD / 2, farba, sirkaCelehoSSD / sirkaDelitel, dlzkaKrizovych);
        this.m.zmenUhol(-uholKrizovych);
        this.segmentList.add(this.m);
        this.l = new Segment(x + sirkaCelehoSSD / 2, y + vyskaCelehoSSD / 2,  farba, sirkaCelehoSSD / sirkaDelitel, vyskaCelehoSSD / 2);
        this.segmentList.add(this.l);
        this.k = new Segment(x + sirkaCelehoSSD / 2, y + vyskaCelehoSSD / 2 - sirkaSegmentu / 2,
            farba, sirkaCelehoSSD / sirkaDelitel, dlzkaKrizovych - sirkaSegmentu / 2);
        this.k.zmenUhol(uholKrizovych);
        this.segmentList.add(this.k);
        this.dlzenSeg = new Segment(x + (sirkaCelehoSSD / 3) * 2, y - sirkaCelehoSSD / 2, farba, sirkaSegmentu, sirkaCelehoSSD / 3);
        this.dlzenSeg.zmenUhol(45);
        this.segmentList.add(this.dlzenSeg);
        this.zhasniVsetko();
        this.x = x;
        this.y = y;
    }

    /**
     * Method getX
     * ziskam X segmentu, pozivam pri skalovatelnom displeji
     * @return The return value
     */
    public int getX() {
        if (this.x == 0) {
            return this.x;
        } 
        return this.x;
    }

    /**
     * Method setFarba
     * nastavim farbu segmentom
     * @param Farba enum
     */
    public void setFarba(Farba farba) {
        //int[] farbaRGB = farba.getRGB(); 

        for (Segment s : this.segmentList) {

            s.zmenFarbu(farba);

        } 

    }

    /**
     * Method setMiesto
     * nastavim miesto a zmenim poziciu, kvoli rotacii ale nedokazem vykreslit sikme segmenty, ktore sa otacali podla "zaciatku", nepozuivam pre istotu
     * @param x A parameter
     * @param y A parameter
     */
    private void setMiesto(int x, int y) {
        for (Segment s : this.segmentList) {
            int[] zakladneMiesto = s.getMiesto();
            s.setMiesto(x + zakladneMiesto[0], y + zakladneMiesto[1]);

        }
    }

    /**
     * Method nastav Int
     * overload nastav - Integer verzia
     * @param jednociferne cislo
     */
    public void nastav(int jednotka) {
        this.somViditelny = true;
        switch (jednotka) {
            case 0:
                this.zobraz0();
                break;
            case 1:
                this.zobraz1();
                break;
            case 2:
                this.zobraz2();
                break;
            case 3:
                this.zobraz3();
                break;
            case 4:
                this.zobraz4();
                break;
            case 5:
                this.zobraz5();
                break;
            case 6:
                this.zobraz6();
                break;
            case 7:
                this.zobraz7();
                break;
            case 8:
                this.zobraz8();
                break;
            case 9:
                this.zobraz9();
                break;
            case 10:
                this.zhasniVsetko();
                this.somViditelny = false;
                break;
            default:
                this.zhasniVsetko();
                this.somViditelny = false;
                break;
        }
    }
    /**
     * Method nastav String
     * overload nastav - Integer verzia
     * @param jednociferne Pismeno
     */
    public void nastav(String pismeno) {
        this.somViditelny = true;

        switch (pismeno) {

            case "0":
                this.zobraz0();
                break;
            case "1":
                this.zobraz1();
                break;
            case "2":
                this.zobraz2();
                break;
            case "3":
                this.zobraz3();
                break;
            case "4":
                this.zobraz4();
                break;
            case "5":
                this.zobraz5();
                break;
            case "6":
                this.zobraz6();
                break;
            case "7":
                this.zobraz7();
                break;
            case "8":
                this.zobraz8();
                break;
            case "9":
                this.zobraz9();
                break;
            case "S":
                this.zobrazS();
                break;
            case "U":
                this.zobrazU();
                break;
            case "P":
                this.zobrazP();
                break;
            case "E":
                this.zobrazE();
                break;
            case "R":
                this.zobrazR();
                break;
            case "A":
                this.zobrazA();
                break;
            case "Á":
                this.zobrazA();
                this.nastavDlzen();
                break;
            case "D":
                this.zobrazD();
                break;
            case "K":
                this.zobrazK();
                break;
            case "O":
                this.zobraz0();
                break;
            case "Z":
                this.zobrazZ();
                break;
            case "L":
                this.zobrazL();
                break;
            case "B":
                this.zobrazB();
                break;
            case "M":
                this.zobrazM();
                break;
            case "C":
                this.zobrazC();
                break;
            case "F":
                this.zobrazF();
                break;
            case "G":
                this.zobrazG();
                break;
            case "H":
                this.zobrazH();
                break;
            case "I":
                this.zobrazI();
                break;
            case "J":
                this.zobrazJ();
                break;
            case "N":
                this.zobrazN();
                break;
            case "T":
                this.zobrazT();
                break;
            case "V":
                this.zobrazV();
                break;
            case "W":
                this.zobrazW();
                break;
            case "X":
                this.zobrazX();
                break;
            case "Y":
                this.zobrazY();
                break;
            case " ":
                this.zhasniVsetko();
                break;
            default:
                this.zhasniVsetko();
                this.zobrazOtaznik();
                this.somViditelny = true;
                break;
        }
    }

    /**
     * Method zobrazOtaznik
     *
     */
    public void zobrazOtaznik() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.g2.rozsviet();    
        this.l.rozsviet();  

    }

    /**
     * Method zobrazL
     *
     */
    public void zobrazL() {
        this.zhasniVsetko();
        this.f.rozsviet();
        this.e.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();    

    }

    /**
     * Method zobrazB
     *
     */
    public void zobrazB() {
        this.zhasniVsetko();
        this.i.rozsviet();
        this.l.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet(); 
        this.g1.rozsviet();
        this.g2.rozsviet(); 
        this.a1.rozsviet();
        this.a2.rozsviet(); 
        this.b.rozsviet();
        this.c.rozsviet();
    }

    /**
     * Method zobrazM
     *
     */
    public void zobrazM() {
        this.zhasniVsetko();
        this.f.rozsviet();
        this.e.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();
        this.j.rozsviet();    
        this.h.rozsviet(); 

    }

    /**
     * Method zobrazZ
     *
     */
    public void zobrazZ() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.j.rozsviet();
        this.k.rozsviet();    
        this.d1.rozsviet(); 
        this.d2.rozsviet();

    }

    /**
     * Method zobrazK
     *
     */
    public void zobrazK() {
        this.zhasniVsetko();
        this.f.rozsviet();
        this.e.rozsviet();
        this.g1.rozsviet();    
        this.j.rozsviet();
        this.m.rozsviet();

    }

    /**
     * Method zobrazD
     *
     */
    public void zobrazD() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.i.rozsviet();
        this.l.rozsviet();    
        this.d1.rozsviet(); 
        this.d2.rozsviet();
        this.c.rozsviet();
        this.b.rozsviet();

    }

    /**
     * Method zobrazS
     *
     */
    public void zobrazS() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet(); 
        this.c.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();

    }

    /**
     * Method zobrazU
     *
     */
    public void zobrazU() {
        this.zhasniVsetko();
        this.b.rozsviet();
        this.c.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();    
        this.e.rozsviet(); 
        this.f.rozsviet();

    }

    /**
     * Method zobrazP
     *
     */
    public void zobrazP() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet(); 
        this.f.rozsviet();
        this.e.rozsviet();

    }

    /**
     * Method zobrazE
     *
     */
    public void zobrazE() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet();
        this.e.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();

    }

    /**
     * Method zobrazR
     *
     */
    public void zobrazR() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet(); 
        this.b.rozsviet();
        this.e.rozsviet();
        this.m.rozsviet();

    }

    /**
     * Method nastavDlzen
     *
     */
    public void nastavDlzen() {
        this.dlzenSeg.rozsviet();

    }

    /**
     * Method zobrazA
     *
     */
    public void zobrazA() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();
        this.e.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet(); 
        //this.dlzen.rozsviet();

    }

    /**
     * Method zobrazAdlzen
     *
     */
    public void zobrazAdlzen() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();
        this.e.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet(); 
        this.dlzenSeg.rozsviet();

    }

    /**
     * Method zobraz0
     *
     */
    public void zobraz0() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();
        this.e.rozsviet();
        this.f.rozsviet();
    }

    /**
     * Method zobraz1
     *
     */
    public void zobraz1() {
        this.zhasniVsetko();
        this.b.rozsviet();
        this.c.rozsviet();
        this.j.rozsviet();
    }

    /**
     * Method zobraz2
     *
     */
    public void zobraz2() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();
        this.e.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet();
    }

    /**
     * Method zobraz3
     *
     */
    public void zobraz3() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet();
    }

    /**
     * Method zobraz4
     *
     */
    public void zobraz4() {
        this.zhasniVsetko();
        this.b.rozsviet();
        this.c.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet();
    }

    /**
     * Method zobraz5
     *
     */
    public void zobraz5() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.c.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet();
    }

    /**
     * Method zobraz6
     *
     */
    public void zobraz6() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.c.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();
        this.e.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet();
    }

    /**
     * Method zobraz7
     *
     */
    public void zobraz7() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();

    }

    /**
     * Method zobraz8
     *
     */
    public void zobraz8() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();
        this.e.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet();
    }

    /**
     * Method zobraz9
     *
     */
    public void zobraz9() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();
        this.f.rozsviet();
        this.g1.rozsviet();    
        this.g2.rozsviet();
    }

    /**
     * Method zobrazC
     *
     */
    public void zobrazC() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a1.rozsviet();
        this.f.rozsviet();
        this.e.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();    

    }

    /**
     * Method zobrazF
     *
     */
    public void zobrazF() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.f.rozsviet();
        this.e.rozsviet();
        this.g1.rozsviet();
        this.g2.rozsviet();    

    }

    /**
     * Method zobrazG
     *
     */
    public void zobrazG() {
        this.zhasniVsetko();
        this.a1.rozsviet();
        this.a1.rozsviet();
        this.f.rozsviet();
        this.e.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();
        this.g2.rozsviet();
        this.c.rozsviet();

    }

    /**
     * Method zobrazH
     *
     */
    public void zobrazH() {
        this.zhasniVsetko();
        this.f.rozsviet();
        this.e.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();
        this.g1.rozsviet();
        this.g2.rozsviet();
    }

    /**
     * Method zobrazI
     *
     */
    public void zobrazI() {
        this.zhasniVsetko();
        this.i.rozsviet();
        this.l.rozsviet();

    }

    /**
     * Method zobrazJ
     *
     */
    public void zobrazJ() {
        this.zhasniVsetko();
        this.b.rozsviet();
        this.c.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();
        this.e.rozsviet();

    }

    /**
     * Method zobrazN
     *
     */
    public void zobrazN() {
        this.zhasniVsetko();
        this.e.rozsviet();
        this.f.rozsviet();
        this.h.rozsviet();
        this.m.rozsviet();
        this.c.rozsviet();
        this.b.rozsviet();

    }

    /**
     * Method zobrazO
     *
     */
    public void zobrazO() {
        this.zhasniVsetko();
        this.f.rozsviet();
        this.e.rozsviet();
        this.b.rozsviet();
        this.c.rozsviet();
        this.a1.rozsviet();
        this.a2.rozsviet();
        this.d1.rozsviet();
        this.d2.rozsviet();

    }

    /**
     * Method zobrazT
     *
     */
    public void zobrazT() {
        this.zhasniVsetko();
        this.l.rozsviet();
        this.i.rozsviet();
        this.a1.rozsviet();
        this.a2.rozsviet();

    }

    /**
     * Method zobrazV
     *
     */
    public void zobrazV() {
        this.zhasniVsetko();
        this.f.rozsviet();
        this.e.rozsviet();
        this.k.rozsviet();
        this.j.rozsviet();

    }

    /**
     * Method zobrazW
     *
     */
    public void zobrazW() {
        this.zhasniVsetko();
        this.f.rozsviet();
        this.e.rozsviet();
        this.c.rozsviet();
        this.b.rozsviet();
        this.k.rozsviet();
        this.m.rozsviet();

    }

    /**
     * Method zobrazX
     *
     */
    public void zobrazX() {
        this.zhasniVsetko();
        this.h.rozsviet();
        this.j.rozsviet();
        this.k.rozsviet();
        this.m.rozsviet();

    }

    /**
     * Method zobrazY
     *
     */
    public void zobrazY() {
        this.zhasniVsetko();
        this.f.rozsviet();
        this.c.rozsviet();
        this.g1.rozsviet();
        this.g2.rozsviet(); 

    }

    /**
     * Method farbyEfektZvlast
     * dokaze zmenit kazdy segment zvlast na nahodnu farbu, nepozuivam
     */
    private void farbyEfektZvlast() {
        for (Segment s : this.segmentList) {
            if (s.jeViditelny()) {
                s.randomFarba();
            }
        }
    }

    /**
     * Method farbyEffektVsetky
     * dokaze zmenit vsetky na rovnaku nahodnu farbu, nepouzivam
     */
    private void farbyEffektVsetky() {
        Farba farba = Farba.randomFarbaFarba();
        for (Segment s : this.segmentList) {
            if (s.jeViditelny()) {
                s.zmenFarbu(farba)  ; 
            }
        }

    }

    /**
     * Method zhasniVsetko
     *
     */
    public void zhasniVsetko() {
        this.a1.zhasni();
        this.a2.zhasni();
        this.b.zhasni();
        this.c.zhasni();
        this.e.zhasni();
        this.f.zhasni();
        this.g1.zhasni();
        this.g2.zhasni();
        this.h.zhasni();
        this.i.zhasni();
        this.j.zhasni(); 
        this.k.zhasni();  
        this.l.zhasni(); 
        this.m.zhasni();
        this.d1.zhasni();
        this.d2.zhasni();
        this.dlzenSeg.zhasni();
    }

}
