import java.awt.Rectangle;
import java.applet.Applet;
import java.applet.AudioClip;
import java.net.URL;
/**
     * Stvorec 
     * @author Karol S
     * @version 1.1.2020
     * okrem this.skry() a this.zobraz() som vsetko prekopal a upravil podla seba
     * 
     */
public class Stvorec {
    private int x;
    private int y;
    private int stranaA;
    private int stranaB;
    private Uhol uhol;
    private int r;
    private int g;
    private int b;
    private int rOld;
    private int gOld;
    private int bOld;
    private boolean jeViditelny;
    //private Manazer manazer;
    private int pridaneSkore;
    private boolean somVybuchnuty;
    private NekonecnocifernyDisplej displejSkore;
    private NekonecnocifernyDisplej bumDisplej;

    /**
     * Stvorec Constructor
     * vytvori stvorec, cez parametre a nasledne si vytvori displeje. - 
     * pri vytvarani displejov iba ked ich potrebujem sekal blueJ, tak som inicializoval hned na zaciatku
     * @param X suradnica
     * @param y suradnica
     * @param Red 0-255
     * @param Green 0-255
     * @param Blue 0-255
     * @param stranaA velkost dolnej strany
     * @param stranaB velkost bocnej strany
     */
    public Stvorec(int x, int y, int r, int g, int b, int stranaA, int stranaB) {
        this.x = x;   //tieto bud budu random, alebo staticke, este uvidim. 
        this.y = y;    //Alebo bude staticke a potom dynamicke aj sandbox verzia.
        this.stranaA = stranaA;
        this.stranaB = stranaB;
        this.r = r;
        this.g = g;
        this.b = b;
        this.ulozOldRGB();
        this.jeViditelny = false;
        this.uhol = new Uhol(0, this.x, this.y);
        this.pridaneSkore = 0;
        this.somVybuchnuty = false;
        this.displejSkore = new NekonecnocifernyDisplej(this.x + this.stranaA / 2, this.y - this.stranaA / 2, this.stranaA / 5, 3);
        this.displejSkore.setFarbuVsetkych(Farba.MODRA);
        this.bumDisplej = new NekonecnocifernyDisplej(this.x + this.stranaA / 6, this.y + this.stranaB / 4, this.stranaA / 5, 3);
    }

    /**
     * Method jeViditelny
     * ci je viditelny tvar
     * @return vrati boolean
     */
    public boolean jeViditelny() {
        return this.jeViditelny;
    }
    
    public boolean jeCerveny() {
        if (this.r == 255) {
            return true;
        }
        return false;
    }
    
    /**
     * Method setViditelnost
     * nastav viditelnost tvaru
     * @param nastav hodnotu boolean
     */
    public void setViditelnost(boolean viditelnost) {
        this.jeViditelny = viditelnost;
    }

    /**
     * Method zmenFarbu
     * zmen farbu tvaru cez RGB hodnoty
     * @param Red
     * @param Green
     * @param Blue
     */
    public void zmenFarbu(int r, int g, int b) {
        this.r = r;
        this.g = g; 
        this.b = b;
        this.nakresliMaRGB();
    }

    /**
     * Method zmenFarbu
     * zmen farbu tvaru cez Farba enum 
     * @param Farba enum
     */
    public void zmenFarbu(Farba farba) {
        int[] farbaArray = farba.getRGB();
        this.r = farbaArray[0];
        this.g = farbaArray[1]; 
        this.b = farbaArray[2];

        if (this.jeViditelny()) {
            this.nakresliMaRGB();
        }
    }

    /**
     * Method ulozOldRGB
     * ulozi si svoje predosle RGB hodnoty
     */
    private void ulozOldRGB() {
        this.rOld = this.r;
        this.gOld = this.g;
        this.bOld = this.b;
    }
    
    /**
     * Method nastavOldRGB
     * nastavi si predosle RGB hodnoty
     */
    private void nastavOldRGB() {
        this.r = this.rOld;
        this.g = this.gOld; 
        this.b = this.bOld;
    }
    
    /**
     * Method zmenUhol
     * zmeni uhol tvaru podla osi , ktoru si urcim - ci v strede bude rotacna os alebo v lavom hornom rohu
     * @param Uhol int v stupnoch
     * @param String ci chcem v strede alebo na lavom hornom rohu, cize zaciatok
     */
    public void zmenUhol(int uhol, String miestoKotvy) {

        switch (miestoKotvy) {
            case "stred":
                this.uhol = new Uhol(uhol, this.x + this.stranaA / 2, this.y + this.stranaB / 2);
                break;
            case "zaciatok":
                this.uhol = new Uhol(uhol, this.x, this.y);
                break;
            default:
                this.uhol = new Uhol(uhol, this.x, this.y);
        }
        this.nakresliMaRGB();
    }

    /**
     * Method setMiesto
     * nastavi miesto tvaru
     * @param x suradnica
     * @param y suradnica
     */
    public void setMiesto(int x, int y) {
        this.x = x;
        this.y = y;
        this.bumDisplej = new NekonecnocifernyDisplej(this.x - this.stranaA / 2, this.y - this.stranaB, 10, 3);
        this.nakresliMaRGB();
    }

    /**
     * Method setDlzky
     * nastavi dlzku stran
     * @param stranaA
     * @param stranaB 
     */
    public void setDlzky(int stranaA, int stranaB) {
        this.stranaA = stranaA;
        this.stranaB = stranaB;
        this.nakresliMaRGB();
    }

    /**
     * Method nakresliMaRGB
     * prekresli sa s uhlom
     */
    public void nakresliMaRGB() { 
        if (!this.jeViditelny()) {
            return;
        }
        Platno canvas = Platno.dajPlatno();
        this.r = r;
        this.g = g;
        this.b = b;

        canvas.drawRGB(this, this.r, this.g, this.b,
            new Rectangle(this.x, this.y, this.stranaA, this.stranaB), this.uhol);
        this.jeViditelny = true;
        if (this.somVybuchnuty()) {
            this.bumDisplej.zobrazAktualnuHodnotu();

        }
    }
    
    /**
     * Method skryMa
     * skryje sa
     */
    public void skryMa() {
        this.bumDisplej.zhasniVsetky();
        this.zmaz();
        this.jeViditelny = false;

    }

    /**
     * Method zobrazMa
     * zobrazi sa
     */
    public void zobrazMa() {
        this.jeViditelny = true;
        this.nakresliMaRGB();
    }

    /**
     * Method zmaz
     * vymaze sa
     */
    public void zmaz() {
        if (this.jeViditelny) {
            Platno canvas = Platno.dajPlatno();
            canvas.erase(this);
        }
    }

    /**
     * Method tik
     * tik metoda kvoli manazerovi , tu sa rozhoduje samotny stvorec, ci tikne  a vybuchne, alebo nie
     */
    public void tik() {
        if ((this.r == 255) && (this.g == 0) && (this.b == 0) && (!this.somVybuchnuty) && (this.jeViditelny()) ) {
            this.somVybuchnuty = true;
            this.vybuchni();
            return;
        }
        this.zhorsujSa();  

    }

    /**
     * Method somVybuchnuty
     * pytam sa ci je vybuchnuty
     * @return The return value
     */
    public boolean somVybuchnuty() {
        return this.somVybuchnuty;
    }

    /**
     * Method vybuchni
     * hovorim mu, nech vybuchne
     */
    public void vybuchni() {
        this.somVybuchnuty = true;
        this.nakresliBum();
        this.nakresliMaRGB();
        URL url = Stvorec.class.getResource("sounds/bum.wav");
        AudioClip clip = Applet.newAudioClip(url);
        clip.play();
        url = null;
        clip = null;
    }

    /**
     * Method nakresliBum
     * nakresli a znazorni , ze vybuchol 
     */
    public void nakresliBum() {
        this.zmenFarbu(Farba.CERVENA);
        this.bumDisplej.setDisplej("BUM");
    }
    
    /**
     * Method vyberSuradnice
     * urci, ci je v zadanych suradniciach alebo nie a rovno si prida body on sam.. stvorec
     * @param x 
     * @param y 
     */
    public void vyberSuradnice(int x, int y) {
        if ((!this.somVybuchnuty()) && (this.somTam(x, y))) {
            this.pridajScore();      
        }        
    }
    
    /**
     * Method vynulujBumDisplej
     * vymaze sa znazornenie vybuchu
     */
    public void vynulujBumDisplej() {
        this.bumDisplej.zhasniVsetky();
    }
    
    /**
     * Method vynulujMa
     * vymaze znazornenie vybuchu , zmeni sa na svoje predosle hodnoty a nastavi, ze neni vybucnuty
     * @return The return value
     */
    public boolean vynulujMa() {
        this.bumDisplej.zhasniVsetky();
        this.nastavOldRGB();
        this.nakresliMaRGB();
        this.somVybuchnuty = false;
        return true;
    } 

    /**
     * Method pickScore
     * metoda sluzi na to, aby ina classa zistila, kolko v sebe drzi bodov
     * @return body
     */
    public int pickScore() {
        int localPriSkore = this.pridaneSkore;
        this.pridaneSkore = 0;
        return localPriSkore;  

    }

    
    /**
     * Method pridajScore
     * sam urci, kolko bodov si do seba ulozi 
     */
    public void pridajScore() {
        int velkost = this.stranaA;
         
        if ((this.r > 200) && (this.g < 50) && (this.b < 50)) {
            this.displejSkore.setDisplej(300);
            this.pridaneSkore = 300;
            this.displejSkore.zasvietZhasniTimeout(1);
            this.vynulujMa();
        } else if ((this.r > 150) && (this.g < 150) && (this.b < 150)) {
            this.displejSkore.setDisplej(100);
            this.pridaneSkore = 100;
            this.displejSkore.zasvietZhasniTimeout(1);
            this.vynulujMa();
        } else {
            this.pridaneSkore = 0;
            this.vybuchni();
        }
        URL url = Stvorec.class.getResource("sounds/klik.wav");
        AudioClip clip = Applet.newAudioClip(url);
        clip.play();
        
    }
    
    /**
     * Method somTam
     * pytam sa , ci je v zadanych suradniciach  alebo nie
     * @param x A parameter
     * @param y A parameter
     * @return vrati ano nie
     */
    public boolean somTam(int x, int y) {
        if ((x >= this.x) && (x <= this.x + stranaA) &&
            (y >= this.y) && (y <= this.y + stranaB) && (this.jeViditelny())) {
            return true;
        }
        return false;
    }
    
    
    
    /**
     * Method zhorsujSa
     * zhorsuje sa , cize meni svoje RGB , kde R bude po case dominantne
     */
    public void zhorsujSa() {

        //Platno canvas = Platno.dajPlatno(); 

        if ((this.r != 255) || (this.g != 0) || (this.b != 0)) {
            
            if (this.r >= 245) {
                this.r = 255;
            } else {
                this.r = this.r + 10;
            }

            if (this.g <= 10) {
                this.g = 0;
            } else {
                this.g = this.g - 10;
            }

            if (this.b <= 10) {
                this.b = 0;
            } else {
                this.b = this.b - 10;
            }
            this.nakresliMaRGB();
            
        }

    }
}
