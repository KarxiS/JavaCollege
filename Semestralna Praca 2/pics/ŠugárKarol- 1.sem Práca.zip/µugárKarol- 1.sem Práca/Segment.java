/**
 * Write a description of class Segment here.
 * segment upraveny, aby vedel si menit farbu, zapojenie enum Farba a zmena uhla
 * @author Cvicenia + Karol S.
 * @version 2.1.2022
 */
public class Segment {
    private StvorecDisplej stvorec;
    private Farba farbaList;
    private int x;
    private int y;
    /**
     * Constructor for objects of class Segment
     */
    public Segment(int x, int y, Farba farba, int stranaA, int stranaB) {
        int[] farbaArray = farba.getRGB();
        this.x = x;
        this.y = y;
        this.stvorec = new StvorecDisplej(x, y, farba, stranaA, stranaB);
    }
    
    /**
     * Method randomFarba
     * poviem, nech sa na nahodnu farbu
     */
    public void randomFarba() { 
        Farba farba = Farba.randomFarbaFarba();
        this.stvorec.zmenFarbu(farba);
    }
    
    /**
     * Method jeViditelny
     * pytam sa ci je viditelny
     * @return ano nie
     */
    public boolean jeViditelny() {
        return this.stvorec.jeViditelny();
    }
    
    /**
     * Method setMiesto
     * zmeni miesto segmentu, nepozivam
     * @param x A parameter
     * @param y A parameter
     */
    public void setMiesto(int x, int y) {
        this.stvorec.setMiesto(x, y);
    }
    
    /**
     * Method getMiesto
     * zisti miesto segmentu
     * @return pole Int
     */
    public int[] getMiesto() {
        int[] suradnice = {this.x, this.y};
        return (suradnice);
    }
    
    /**
     * skopirovane z hodiny
     *
     */
    public void rozsviet() {
        this.stvorec.zobrazMa();
        //this.stvorec.setViditelnost(true);
        
    }
    
    /**
     * Method zmenUhol
     * zmeni uhol segmentu
     * @param na kolko zmenit int 
     */
    public void zmenUhol(int nakolko) {
        this.stvorec.zmenUhol(nakolko, "zaciatok");
    
    }
    
    /**
     * Method zmenFarbu
     * zmenim farbu cez enum Farba
     * @param farba Farba
     */
    public void zmenFarbu(Farba farba) {
        this.stvorec.zmenFarbu(farba);
    }
    
    
     
    /**
     * Method zhasni
     * skopirovane z cviceni
     */
    public void zhasni() {
        this.stvorec.skryMa();  
    }
}
