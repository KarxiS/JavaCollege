
/**
 * Enumeration class TypMapa - write a description of the enum class here
 * ukladanie obtiaznosti, cize levelov mapy
 * @author Karol Sugar
 * @version 1.1.2022
 */
public enum MapaLevel {
    TEST("Test", 0, 99, 2000, 1),
    PRVA("Prva", 8, 15, 2000, 2),
    DRUHA("Druha", 10, 50, 10000, 2),
    FINAL("Final", 5, 15, 1700, 2);
    private int pocetBomb;
    private int cas; 
    private int potrebnyPocetBodov;
    private int powerMax;
    private String nazov;
    /**
     * MapaLevel Constructor
     * enum Mapa Level 
     * @param nazov A parameter
     * @param pocetBomb A parameter
     * @param cas A parameter
     * @param potrebnyPocetBodov A parameter
     * @param powerMax A parameter
     */
    MapaLevel(String nazov, int pocetBomb, int cas, int potrebnyPocetBodov, int powerMax) {
        this.pocetBomb = pocetBomb;
        this.cas = cas;
        this.powerMax = powerMax;
        this.potrebnyPocetBodov = potrebnyPocetBodov;
        this.nazov = nazov;
    }

    
    
    /**
     * Method getPocetBomb
     *
     * @return ziskam Pocet bomb
     */
    public int getPocetBomb() {
        return this.pocetBomb;
    }
    
    /**
     * Method getCas
     * ziskam cas, ako dlho mapa sa bude hrat
     * @return The return value
     */
    public int getCas() {
        return this.cas;
    }
    
    /**
     * Method getPotrebnyPocetBodov
     * potrebny pocet bodov na prejdenie mapy
     * @return The return value
     */
    public int getPotrebnyPocetBodov() {
        return this.potrebnyPocetBodov;
    }
    
    /**
     * Method getNazov
     * ako sa vola mapa
     * @return The return value
     */
    public String getNazov() {
        return this.nazov;
    }
    
    /**
     * Method getPowerMax
     * maximalny pocet power na mape
     * @return The return value
     */
    public int getPowerMax() {
        return this.powerMax;
    }
    
    /**
     * Method toString
     * to iste ako getNazov, len som chcel implementovat aj moznost pouzit println(this)
     * @return string
     */
    public String toString() { 
        return this.nazov; 
    }
    
}
