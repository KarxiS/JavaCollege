
/**
 * Classa Uhol drzi v sebe dolezite informacie pri rotacii a vypocitavani potrebnych hodnot
 * 
 * @author Karol S.
 * @version 1.1.2022
 */
public class Uhol {
    private int uhol;
    private int kotvaX; 
    private int kotvaY;
    public Uhol(int uhol, int kotvaX, int kotvaY) {
        this.uhol = uhol;
        this.kotvaX = kotvaX;
        this.kotvaY = kotvaY;
    }
    
    public int getUhol() {
        return this.uhol;
    }
    
    public int getKotvaX() {
        return this.kotvaX;
    }
    
    public int getKotvaY() {
        return this.kotvaY;
    }
    
    
    
    
}
