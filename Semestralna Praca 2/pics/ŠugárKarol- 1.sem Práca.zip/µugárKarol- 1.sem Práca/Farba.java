import java.util.Random;
/**
 * Enumeration class Farby - write a description of the enum class here
 * tento enum drzi konstanty, ktore dokaze platno cez string hodnotu v frontColor metode urcit. Vyrazil som bielu, lebo tu neni vidno
 * @author Karol S.
 * @version 1.1.2022
 */
public enum Farba {
    CERVENA("red", 255, 0, 0),

    CIERNA("black", 0, 0, 0),

    MODRA("blue", 0, 0, 255),

    ZLTA("yellow", 255, 255, 0),

    ZELENA("green", 0, 255, 0),

    RUZOVA("magenta", 255, 0, 255);

    //BIELA("white", 255,255,255)
    

    private  String oznaceniePrePlatno;
    private int r;
    private int g;
    private int b;

    /**
     * Farba Constructor
     * urcenie stringu, ktoremu platno pochopi pri vykreslovani 
     * @param oznaceniePrePlatno
     * @param r 
     * @param g 
     * @param b 
     */
    Farba(String oznaceniePrePlatno, int r, int g, int b) {
        this.oznaceniePrePlatno = oznaceniePrePlatno;
        this.r = r;
        this.g = g; 
        this.b = b;
    }

    /**
     * Method getOznaceniePrePlatno
     * ziskam string, pre vykreslenie farby pre platno
     * @return String
     */
    public String getOznaceniePrePlatno() {
        return this.oznaceniePrePlatno;
    }
    
    /**
     * Method randomFarbaRGB
     * vyberie nahodnu farbu bez inicializovania sa
     * @return pole integerov s tromi prvkami - postupnost R G B. mohol som daj aj dalsiu obalovaciu classu, ale takto sa vyznam.
     */
    public static int[] randomFarbaRGB() {
        Random random = new Random();
        Farba farba = Farba.values()[random.nextInt(Farba.values().length)];
        return farba.getRGB();
    }
    
    /**
     * Method randomFarbaString
     * vrati nahodnu farbu rovno so stringom pre platno
     * @return String
     */
    public static String randomFarbaString() {
        Random random = new Random();
        Farba farba = Farba.values()[random.nextInt(Farba.values().length)];
        Farba farba2 = Farba.values()[1];
        return farba.oznaceniePrePlatno;
    }
    
    /**
     * Method randomFarbaFarba
     *vrati nahodnu farbu rovno so objektom Farba pre vseobecne pouzitie
     * @return Farba
     */
    public static Farba randomFarbaFarba() {
        Random random = new Random();
        Farba farba = Farba.values()[random.nextInt(Farba.values().length)];
        return farba;
    }
    
    /**
     * Method getRGB
     * pri oznaceni pouzijem toto, aby som mohol z napr Farba.ZELENA dostat RGB hodnoty
     * @return pole RGB postupne
     */
    public int[] getRGB() {
        int[] rgb = {this.r, this.g, this.b};
        return rgb;
    }
    
    /**
     * Method getR
     * ziskam len R
     * @return R v int
     */
    public int getR() {
        
        return this.r;
    }
    
    /**
     * Method getG
     * ziskam len G
     * @return G v int
     */
    public int getG() {
        
        return this.g;
    }
    
    /**
     * Method getB
     * ziskam len B
     * @return B v int
     */
    public int getB() {
        
        return this.b;
    }
}
